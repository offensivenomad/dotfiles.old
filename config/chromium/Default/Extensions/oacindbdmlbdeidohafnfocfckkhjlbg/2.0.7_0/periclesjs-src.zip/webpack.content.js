const TerserPlugin = require("terser-webpack-plugin");
const path = require("path");
const mode = process.env.NODE_ENV || "development";

const config = {
  entry: {
    app: ["@babel/polyfill", "./content/content.js"]
  },
  mode: mode,
  output: {
    path: path.resolve(__dirname, "bundle"),
    filename: "content-bundle.js",
    publicPath: "/"
  },
  optimization: {
    splitChunks: {
      filename: "content-vendors.js",
      chunks: "all"
    },
    minimizer: []
  },
  module: {
    rules: [
      {
        test: /\.(js)$/,
        exclude: "/node_modules/",
        use: ["babel-loader"]
      },
      {
        test: /\.css$/,
        use: [
          // MiniCssExtractPlugin.loader,
          "style-loader",
          "css-loader"
        ]
      }
    ]
  }
};
if (mode === "production") {
  config.optimization.minimizer.push(
    new TerserPlugin({
      terserOptions: {
        compress: {
          drop_console: true
        }
      }
    })
  );
}

module.exports = config;
