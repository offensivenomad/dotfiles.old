#!/bin/bash

echo "cleanup static bundle/static"
rm -fr bundle/static

echo "copy index.html into popup.html"
cp build/index.html bundle/popup.html

echo "copy build/static to bundle/static"
cp -R build/static bundle/static

echo "copy manifest"
cp build/manifest.json bundle/manifest.json

