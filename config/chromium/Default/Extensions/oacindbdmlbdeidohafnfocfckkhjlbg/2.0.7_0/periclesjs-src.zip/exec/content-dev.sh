#!/bin/bash

echo "Content"
npm run build-content

echo "Create zip bundle"
cd bundle
zip -r build.zip . -x *.DS_Store
