#!/bin/bash

echo "Popup"
npm run build:prod

echo "Copying from build to bundle"
source ./exec/copy.sh

echo "Create zip bundle"
cd bundle
zip -r build.zip . -x *.DS_Store
