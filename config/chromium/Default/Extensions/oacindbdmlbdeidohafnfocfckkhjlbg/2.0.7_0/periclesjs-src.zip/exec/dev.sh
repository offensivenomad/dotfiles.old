#!/bin/bash

echo "** Building for Development"

echo "Popup"
npm run build

echo "Content"
npm run build-content

echo "Background"
npm run build-background

echo "Copying from build to bundle"
source ./exec/copy.sh

echo "Create zip bundle"
cd bundle
zip -r build.zip . -x *.DS_Store
