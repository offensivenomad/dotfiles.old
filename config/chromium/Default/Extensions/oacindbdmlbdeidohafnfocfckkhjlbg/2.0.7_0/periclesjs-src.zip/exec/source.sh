#!/usr/bin/env bash

zip -r periclesjs-src.zip . -x "build*" bundle/build.zip  bundle/popup.html bundle/manifest.json "bundle/static*" "bundle/content*" "bundle/vendors*" "bundle/background*" node_modules/**\* node_modules/ *.zip .git/**\* .git/ .idea/ .idea/**\* .*.* .*

# mv periclesjs-src.zip ~/Downloads
mv periclesjs-src.zip bundle/

