#!/bin/bash

echo "Background"
npm run build-background

echo "Create zip bundle"
cd bundle
zip -r build.zip . -x *.DS_Store
