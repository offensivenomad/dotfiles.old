## Pericles 2.0

First, install dependencies:

### `npm install`

After the dependencies are installed, this script is used to obtain the final build.
Output will be stored in _bundle/build.zip_

### `exec/prod.sh`

This source (that is submitted along with the build) is generated with.
Output will be stored in _bundle/periclesjs-src.zip_

### `exec/source.sh`
