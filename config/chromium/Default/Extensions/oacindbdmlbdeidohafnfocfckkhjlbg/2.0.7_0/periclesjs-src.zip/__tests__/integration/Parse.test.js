// import para from "../mock/SonestownCoveredBridge";
import hltvBody from "../mock/hltvPost1";
import wikiBody from "../mock/SonestownCoveredBridge";
import lcoBody from "../mock/loc-cdo.org";

import WebsiteParser from "../../content/html-parser/html-parser.website";

describe("Process sentences in paragraphs", () => {
  // https://www.lco-cdo.org/en/our-current-projects/the-law-and-persons-with-disabilities/persons-with-disabilities-final-report-september-2012/iii-principles-for-the-law-as-it-affects-persons-with-disabilities/
  test("skips empty paragraph", async () => {
    const wb = new WebsiteParser();
    wb.document = document;
    const body = document.createElement("body");
    body.insertAdjacentHTML("afterbegin", lcoBody);
    const paragraphs = body.querySelectorAll("p");
    const promises = [];
    paragraphs.forEach(p => {
      promises.push(wb.processSentencesInParagraphs(p));
    });

    await Promise.all(promises);
    expect(wb.sentenceIndex).toBe(wb.textsToRead.length);
  });

  // https://www.hltv.org/news/29301/astralis-edge-out-ence-in-three-map-series
  test("read hltv", async () => {
    const wb = new WebsiteParser();
    wb.document = document;
    const body = document.createElement("body");
    body.insertAdjacentHTML("afterbegin", hltvBody);
    const paragraphs = body.querySelectorAll("p");
    const promises = [];
    paragraphs.forEach(p => {
      promises.push(wb.processSentencesInParagraphs(p));
    });

    await Promise.all(promises);
    expect(wb.sentenceIndex).toBe(wb.textsToRead.length);
  });

  // https://en.wikipedia.org/wiki/Sonestown_Covered_Bridge
  test("read wiki", async () => {
    const wb = new WebsiteParser();
    wb.document = document;
    const body = document.createElement("body");
    body.insertAdjacentHTML("afterbegin", wikiBody);
    const paragraphs = body.querySelectorAll("p");
    const promises = [];
    paragraphs.forEach(p => {
      promises.push(wb.processSentencesInParagraphs(p));
    });

    await Promise.all(promises);
    expect(wb.sentenceIndex).toBe(wb.textsToRead.length);
  });
});
