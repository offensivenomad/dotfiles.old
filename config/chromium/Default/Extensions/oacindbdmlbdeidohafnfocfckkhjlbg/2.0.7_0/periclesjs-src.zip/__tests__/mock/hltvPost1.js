export default `<div xmlns="http://www.w3.org/1999/xhtml" class="newstext-con">
                  <p class="headertext" itemprop="description">Despite being contested by <a href="/team/4869/ence" data-tooltip-id="uid965273204">ENCE</a> on all three maps, <a href="/team/6665/astralis" data-tooltip-id="uid1396166367">Astralis</a> were able to overcome the Finnish side and secure the 2-1 victory in ESL Pro League Season 11.</p>
                  <p class="news-block">Ranked #2 in the world, <a href="/team/6665/astralis" data-tooltip-id="uid1396166367">Astralis</a> were overwhelming favorites to win the series, despite their shocking 2-0 loss to <a href="/team/4411/nip" data-tooltip-id="uid463252213">NiP</a> in the opening match of the tournament. On the other hand, <a href="/team/4869/ence" data-tooltip-id="uid965273204">ENCE</a> have continued their struggles by opening Pro League with losses to <a href="/team/7020/spirit" data-tooltip-id="uid1994267275">Spirit</a> and <a href="/team/9565/vitality" data-tooltip-id="uid593073487">Vitality</a>, witha  bounce-back not expected in the game against <a href="/team/6665/astralis" data-tooltip-id="uid1396166367">Astralis</a>.</p>
                  <p class="news-block">However, the series ended up being a back-and-forth one, with <a href="/team/4869/ence" data-tooltip-id="uid965273204">ENCE</a> recovering from slow starts on all three maps. In the end, <a href="/team/6665/astralis" data-tooltip-id="uid1396166367">Astralis</a> secured the narrow victory thanks to a 10-round streak on the final map, Overpass.</p>
                  <div class="image-con"><a href="https://www.hltv.org/gallery/view/139336"><img alt="" src="https://static.hltv.org/images/galleries/12126-medium/1582549692.9407.jpeg" class="image" itemprop="image" /></a>
                    <div class="imagetext">dupreeh's impressive performance on Dust2 was crucial to Astralis' win</div>
                  </div>
                  <p class="news-block">Dust2 kicked off with a 5-0 lead for <a href="/team/6665/astralis" data-tooltip-id="uid1396166367">Astralis</a>, but <a href="/team/4869/ence" data-tooltip-id="uid965273204">ENCE</a> didn't let the Danes run away with the scoreline so easily. Playing on the Terrorist side, <a href="/team/4869/ence" data-tooltip-id="uid965273204">ENCE</a> came back into the half by winning eight of the next nine rounds to finish the half with a minimal lead, 8-7. <a href="/player/695/allu" class="a-reset normal-weight" data-tooltip-id="uid264508618">Aleksi <span class="bold a-default">"allu"</span> Jalli</a>'s men took the lead after the switch thanks to the pistol round win, but it was all about <a href="/team/6665/astralis" data-tooltip-id="uid1396166367">Astralis</a> in the rifle rounds. The Danish side closed out the game, 16-13, as <a href="/player/7398/dupreeh" class="a-reset normal-weight" data-tooltip-id="uid1659752966">Peter <span class="bold a-default">"dupreeh"</span> Rasmussen</a> led the way with 33 frags.</p>
                  <p class="news-block">Inferno followed a similar pattern to Dust2, <a href="/team/6665/astralis" data-tooltip-id="uid1396166367">Astralis</a> won the early game (6-3 as Terrorists), but <a href="/team/4869/ence" data-tooltip-id="uid965273204">ENCE</a> were able to wake up and claim the lead before the switch. In the second half, <a href="/team/6665/astralis" data-tooltip-id="uid1396166367">Astralis</a> ran away with the lead by putting up strong defenses, but they were unable to close out the game from 14-9 up as <a href="/team/4869/ence" data-tooltip-id="uid965273204">ENCE</a> mounted a miraculous comeback to force map 3, Overpass.</p>
                  <p class="news-block">On the decider, <a href="/player/11916/sergej" class="a-reset normal-weight" data-tooltip-id="uid120942811">Jere <span class="bold a-default">"sergej"</span> Salo</a> continued his strong play to bring <a href="/team/4869/ence" data-tooltip-id="uid965273204">ENCE</a> back from another slow start (0-4) to a respectable 9-6 lead after the CT half. <a href="/player/11916/sergej" data-tooltip-id="uid120942811">sergej</a>'s triple secured the second pistol round for the Finns, but <a href="/team/6665/astralis" data-tooltip-id="uid1396166367">Astralis</a> mustered a force-buy win and started to build momentum on the defense. In the end, <a href="/player/7412/gla1ve" class="a-reset normal-weight" data-tooltip-id="uid653273767">Lukas <span class="bold a-default">"gla1ve"</span> Rossander</a> and co. closed out the map without losing a single round on the CT side (16-10) to secure their second Pro League victory of the season.</p>
                  <div class="newsitem-match-result">
                    <div class="newsitem-match-result-top"><span class="text-ellipsis bold"><a href="/events/5226/esl-pro-league-season-11-europe">ESL Pro League Season 11 Europe</a></span><span class="newsitem-match-type bold">Best of 3</span></div>
                    <div class="newsitem-match-result-middle">
                      <div class="newsitem-match-result-team-con">
                        <div class="newsitem-match-result-team">
                          <div class="newsitem-match-result-team-logo-con"><img alt="Astralis" src="https://static.hltv.org/images/team/logo/6665" class="" title="Astralis" /></div>
<a href="/team/6665/astralis">Astralis</a></div>
<img alt="Denmark" src="https://static.hltv.org/images/bigflags/30x20/DK.gif" class="newsitem-match-result-team-flag-left flag" title="Denmark" /></div>
                      <div class="newsitem-match-result-score-con"><a href="/matches/2340078/astralis-vs-ence-esl-pro-league-season-11-europe">Matchpage</a>
                        <div>
                          <div class="newsitem-match-result-score scorewon">2</div>
                          <div class="newsitem-match-result-score"></div>
                          <div class="newsitem-match-result-score scorelost">1</div>
                        </div>
                        <div class="newsitem-match-result-date" data-time-format="do MMMM yyyy" data-unix="1584738000000">20th March 2020</div>
                      </div>
                      <div class="newsitem-match-result-team-con"><img alt="Finland" src="https://static.hltv.org/images/bigflags/30x20/FI.gif" class="newsitem-match-result-team-flag-right flag" title="Finland" />
                        <div class="newsitem-match-result-team">
                          <div class="newsitem-match-result-team-logo-con"><img alt="ENCE" src="https://static.hltv.org/images/team/logo/4869" class="" title="ENCE" /></div>
<a href="/team/4869/ence">ENCE</a></div>
                      </div>
                    </div>
                    <div class="newsitem-match-result-map">
                      <div class="newsitem-match-result-map-score-won">16</div>
<a href="/stats/matches/mapstatsid/100521/astralis-vs-ence" class="newsitem-match-result-map-name">Dust2</a>
                      <div class="newsitem-match-result-map-score-faded">13</div>
                    </div>
                    <div class="newsitem-match-result-map">
                      <div class="newsitem-match-result-map-score-faded">14</div>
<a href="/stats/matches/mapstatsid/100522/ence-vs-astralis" class="newsitem-match-result-map-name">Inferno</a>
                      <div class="newsitem-match-result-map-score-won">16</div>
                    </div>
                    <div class="newsitem-match-result-map">
                      <div class="newsitem-match-result-map-score-won">16</div>
<a href="/stats/matches/mapstatsid/100523/ence-vs-astralis" class="newsitem-match-result-map-name">Overpass</a>
                      <div class="newsitem-match-result-map-score-faded">10</div>
                    </div>
                  </div>
                  <div class="newsitem-match-stats">
                    <table class="newsitem-match-stats-table">
                      <thead>
                        <tr class="newsitem-match-stats-header">
                          <th class="newsitem-match-stats-team"><img alt="Astralis" src="https://static.hltv.org/images/team/logo/6665" class="newsitem-match-stats-logo" title="Astralis" /> <a href="/team/6665/astralis">Astralis</a></th>
                          <th class="newsitem-match-stats-kd">K - D</th>
                          <th class="newsitem-match-stats-kdDiff">+/-</th>
                          <th class="newsitem-match-stats-adr">ADR</th>
                          <th class="newsitem-match-stats-rating">Rating 2.0</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr class="newsitem-match-stats-row">
                          <td class="newsitem-match-stats-team"><img alt="Denmark" src="https://static.hltv.org/images/bigflags/30x20/DK.gif" class="flag" title="Denmark" /> <a href="/player/4954/Xyp9x" class="newsitem-match-stats-team-name gtSmartphone-only">Andreas<span class="bold"> 'Xyp9x' </span>Højsleth</a><a href="/player/4954/Xyp9x" class="newsitem-match-stats-team-name smartphone-only"><span class="bold">Xyp9x</span></a></td>
                          <td class="newsitem-match-stats-kd">63 - 46</td>
                          <td class="newsitem-match-stats-kdDiff won">+17</td>
                          <td class="newsitem-match-stats-adr">82.8</td>
                          <td class="newsitem-match-stats-rating">1.26</td>
                        </tr>
                        <tr class="newsitem-match-stats-row">
                          <td class="newsitem-match-stats-team"><img alt="Denmark" src="https://static.hltv.org/images/bigflags/30x20/DK.gif" class="flag" title="Denmark" /> <a href="/player/7398/dupreeh" class="newsitem-match-stats-team-name gtSmartphone-only">Peter<span class="bold"> 'dupreeh' </span>Rasmussen</a><a href="/player/7398/dupreeh" class="newsitem-match-stats-team-name smartphone-only"><span class="bold">dupreeh</span></a></td>
                          <td class="newsitem-match-stats-kd">70 - 57</td>
                          <td class="newsitem-match-stats-kdDiff won">+13</td>
                          <td class="newsitem-match-stats-adr">91.2</td>
                          <td class="newsitem-match-stats-rating">1.26</td>
                        </tr>
                        <tr class="newsitem-match-stats-row">
                          <td class="newsitem-match-stats-team"><img alt="Denmark" src="https://static.hltv.org/images/bigflags/30x20/DK.gif" class="flag" title="Denmark" /> <a href="/player/9032/Magisk" class="newsitem-match-stats-team-name gtSmartphone-only">Emil<span class="bold"> 'Magisk' </span>Reif</a><a href="/player/9032/Magisk" class="newsitem-match-stats-team-name smartphone-only"><span class="bold">Magisk</span></a></td>
                          <td class="newsitem-match-stats-kd">59 - 49</td>
                          <td class="newsitem-match-stats-kdDiff won">+10</td>
                          <td class="newsitem-match-stats-adr">73.4</td>
                          <td class="newsitem-match-stats-rating">1.14</td>
                        </tr>
                        <tr class="newsitem-match-stats-row">
                          <td class="newsitem-match-stats-team"><img alt="Denmark" src="https://static.hltv.org/images/bigflags/30x20/DK.gif" class="flag" title="Denmark" /> <a href="/player/7592/device" class="newsitem-match-stats-team-name gtSmartphone-only">Nicolai<span class="bold"> 'device' </span>Reedtz</a><a href="/player/7592/device" class="newsitem-match-stats-team-name smartphone-only"><span class="bold">device</span></a></td>
                          <td class="newsitem-match-stats-kd">55 - 50</td>
                          <td class="newsitem-match-stats-kdDiff won">+5</td>
                          <td class="newsitem-match-stats-adr">66.6</td>
                          <td class="newsitem-match-stats-rating">1.09</td>
                        </tr>
                        <tr class="newsitem-match-stats-row">
                          <td class="newsitem-match-stats-team"><img alt="Denmark" src="https://static.hltv.org/images/bigflags/30x20/DK.gif" class="flag" title="Denmark" /> <a href="/player/7412/gla1ve" class="newsitem-match-stats-team-name gtSmartphone-only">Lukas<span class="bold"> 'gla1ve' </span>Rossander</a><a href="/player/7412/gla1ve" class="newsitem-match-stats-team-name smartphone-only"><span class="bold">gla1ve</span></a></td>
                          <td class="newsitem-match-stats-kd">51 - 53</td>
                          <td class="newsitem-match-stats-kdDiff lost">-2</td>
                          <td class="newsitem-match-stats-adr">70.8</td>
                          <td class="newsitem-match-stats-rating">1.05</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                  <div class="newsitem-match-stats">
                    <table class="newsitem-match-stats-table">
                      <thead>
                        <tr class="newsitem-match-stats-header">
                          <th class="newsitem-match-stats-team"><img alt="ENCE" src="https://static.hltv.org/images/team/logo/4869" class="newsitem-match-stats-logo" title="ENCE" /> <a href="/team/4869/ence">ENCE</a></th>
                          <th class="newsitem-match-stats-kd">K - D</th>
                          <th class="newsitem-match-stats-kdDiff">+/-</th>
                          <th class="newsitem-match-stats-adr">ADR</th>
                          <th class="newsitem-match-stats-rating">Rating 2.0</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr class="newsitem-match-stats-row">
                          <td class="newsitem-match-stats-team"><img alt="Finland" src="https://static.hltv.org/images/bigflags/30x20/FI.gif" class="flag" title="Finland" /> <a href="/player/11916/sergej" class="newsitem-match-stats-team-name gtSmartphone-only">Jere<span class="bold"> 'sergej' </span>Salo</a><a href="/player/11916/sergej" class="newsitem-match-stats-team-name smartphone-only"><span class="bold">sergej</span></a></td>
                          <td class="newsitem-match-stats-kd">65 - 57</td>
                          <td class="newsitem-match-stats-kdDiff won">+8</td>
                          <td class="newsitem-match-stats-adr">79.7</td>
                          <td class="newsitem-match-stats-rating">1.13</td>
                        </tr>
                        <tr class="newsitem-match-stats-row">
                          <td class="newsitem-match-stats-team"><img alt="Finland" src="https://static.hltv.org/images/bigflags/30x20/FI.gif" class="flag" title="Finland" /> <a href="/player/5479/suNny" class="newsitem-match-stats-team-name gtSmartphone-only">Miikka<span class="bold"> 'suNny' </span>Kemppi</a><a href="/player/5479/suNny" class="newsitem-match-stats-team-name smartphone-only"><span class="bold">suNny</span></a></td>
                          <td class="newsitem-match-stats-kd">55 - 62</td>
                          <td class="newsitem-match-stats-kdDiff lost">-7</td>
                          <td class="newsitem-match-stats-adr">66.2</td>
                          <td class="newsitem-match-stats-rating">0.95</td>
                        </tr>
                        <tr class="newsitem-match-stats-row">
                          <td class="newsitem-match-stats-team"><img alt="Finland" src="https://static.hltv.org/images/bigflags/30x20/FI.gif" class="flag" title="Finland" /> <a href="/player/7248/xseveN" class="newsitem-match-stats-team-name gtSmartphone-only">Sami<span class="bold"> 'xseveN' </span>Laasanen</a><a href="/player/7248/xseveN" class="newsitem-match-stats-team-name smartphone-only"><span class="bold">xseveN</span></a></td>
                          <td class="newsitem-match-stats-kd">49 - 58</td>
                          <td class="newsitem-match-stats-kdDiff lost">-9</td>
                          <td class="newsitem-match-stats-adr">66.5</td>
                          <td class="newsitem-match-stats-rating">0.89</td>
                        </tr>
                        <tr class="newsitem-match-stats-row">
                          <td class="newsitem-match-stats-team"><img alt="Finland" src="https://static.hltv.org/images/bigflags/30x20/FI.gif" class="flag" title="Finland" /> <a href="/player/4076/Aerial" class="newsitem-match-stats-team-name gtSmartphone-only">Jani<span class="bold"> 'Aerial' </span>Jussila</a><a href="/player/4076/Aerial" class="newsitem-match-stats-team-name smartphone-only"><span class="bold">Aerial</span></a></td>
                          <td class="newsitem-match-stats-kd">44 - 67</td>
                          <td class="newsitem-match-stats-kdDiff lost">-23</td>
                          <td class="newsitem-match-stats-adr">65.6</td>
                          <td class="newsitem-match-stats-rating">0.88</td>
                        </tr>
                        <tr class="newsitem-match-stats-row">
                          <td class="newsitem-match-stats-team"><img alt="Finland" src="https://static.hltv.org/images/bigflags/30x20/FI.gif" class="flag" title="Finland" /> <a href="/player/695/allu" class="newsitem-match-stats-team-name gtSmartphone-only">Aleksi<span class="bold"> 'allu' </span>Jalli</a><a href="/player/695/allu" class="newsitem-match-stats-team-name smartphone-only"><span class="bold">allu</span></a></td>
                          <td class="newsitem-match-stats-kd">41 - 54</td>
                          <td class="newsitem-match-stats-kdDiff lost">-13</td>
                          <td class="newsitem-match-stats-adr">55.2</td>
                          <td class="newsitem-match-stats-rating">0.81</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                  <p class="news-block">With the third set of ESL Pro League S11 Group A matches played out, this is how the standings look like:</p>
                  <div class="newsitem-groups">
                    <div class="newsitem-groups-grid">
                      <div class="newsitem-group">
                        <div class="newsitem-groups-name"><span class="newsitem-groups-name-text">Group A</span></div>
                        <div class="newsitem-groupresults-header"><span>TEAM</span><span>POINTS</span></div>
                        <div class="newsitem-groups-entries"><a href="/team/4411/nip" class="newsitem-groups-entry last-above-marker moves-up">
                            <div class="newsitem-groups-team" data-tooltip-id="uid463252213"><img alt="NiP" src="https://static.hltv.org/images/team/logo/4411" class="newsitem-groups-logo" title="NiP" /> NiP</div>
                            <div class="newsitem-groups-points">9</div>
                          </a><a href="/team/7020/spirit" class="newsitem-groups-entry below-marker moves-relegation">
                            <div class="newsitem-groups-team" data-tooltip-id="uid1994267275"><img alt="Spirit" src="https://static.hltv.org/images/team/logo/7020" class="newsitem-groups-logo" title="Spirit" /> Spirit</div>
                            <div class="newsitem-groups-points">6</div>
                          </a><a href="/team/6665/astralis" class="newsitem-groups-entry below-marker moves-relegation">
                            <div class="newsitem-groups-team" data-tooltip-id="uid1396166367"><img alt="Astralis" src="https://static.hltv.org/images/team/logo/6665" class="newsitem-groups-logo" title="Astralis" /> Astralis</div>
                            <div class="newsitem-groups-points">6</div>
                          </a><a href="/team/9565/vitality" class="newsitem-groups-entry below-marker moves-down">
                            <div class="newsitem-groups-team" data-tooltip-id="uid593073487"><img alt="Vitality" src="https://static.hltv.org/images/team/logo/9565" class="newsitem-groups-logo" title="Vitality" /> Vitality</div>
                            <div class="newsitem-groups-points">6</div>
                          </a><a href="/team/4869/ence" class="newsitem-groups-entry below-marker moves-down">
                            <div class="newsitem-groups-team" data-tooltip-id="uid965273204"><img alt="ENCE" src="https://static.hltv.org/images/team/logo/4869" class="newsitem-groups-logo" title="ENCE" /> ENCE</div>
                            <div class="newsitem-groups-points">0</div>
                          </a><a href="/team/6902/godsent" class="newsitem-groups-entry below-marker moves-down">
                            <div class="newsitem-groups-team" data-tooltip-id="uid2141823644"><img alt="GODSENT" src="https://static.hltv.org/images/team/logo/6902" class="newsitem-groups-logo" title="GODSENT" /> GODSENT</div>
                            <div class="newsitem-groups-points">0</div>
                          </a></div>
                      </div>
                    </div>
                  </div>
                </div>`;
