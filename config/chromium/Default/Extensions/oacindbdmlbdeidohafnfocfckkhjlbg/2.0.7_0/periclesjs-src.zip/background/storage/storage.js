/*eslint-disable */
const core = chrome || browser;
/*eslint-enable */
const storage = core.storage.local;

const s = {
  // get generic
  get: async name => {
    return new Promise(async (resolve, reject) => {
      storage.get(name, async data => {
        resolve(data[name]);
      });
    });
  },

  // set generic
  set: async (name, value) => {
    return new Promise(async (resolve, reject) => {
      const data = {};
      data[name] = value;
      await storage.set(data);
      resolve(data);
    });
  }
};

export default s;
