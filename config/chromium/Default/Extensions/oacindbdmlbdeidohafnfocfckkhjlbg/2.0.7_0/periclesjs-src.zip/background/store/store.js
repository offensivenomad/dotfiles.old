import { createEpicMiddleware } from "redux-observable";
import thunk from "redux-thunk";
import { wrapStore } from "webext-redux";
import { createStore, applyMiddleware } from "redux";
import reducer from "../../src/store/reducer";

export const observableMiddleware = createEpicMiddleware();
const store = createStore(
  reducer,
  applyMiddleware(observableMiddleware, thunk)
);
wrapStore(store);

export default store;
