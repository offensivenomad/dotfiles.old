export const INSTALLED_URL = "http://pericles.alexandrucalin.me/installed?v=";
