import store, { observableMiddleware } from "./store/store";
import speech from "./speech/speech";
import { tap, ignoreElements } from "rxjs/operators";
import { PLAYER, SETTINGS, PARSER } from "../src/core/types";
import { ofType } from "redux-observable";
import { getContentTabId } from "../src/lib/mp/mp";
import { reportGA, getBrowserAPI } from "../src/util/util";
import { INSTALLED_URL } from "./constants/constants";
import storage from "./storage/storage";
import nlp from "compromise";
import { IS_FIREFOX } from "../src/core/constants";
console.log("what is this global", global);

const browserAPI = getBrowserAPI();
// const synth = window.speechSynthesis;
const fns = {};
let voiceNames = [];
// reset pericles with factory setting
// browser.storage.local.clear();
// console.log("RESET FROM FACTORY");
// console.log("Pericles.background.init");

reportGA();

fns.utter = async text => {
  if (!text.trim().length) return;
  const sentences = nlp(text)
    .sentences()
    .data();
  if (!sentences) return;
  store.dispatch({
    type: PARSER.ACTION.SET_SECTIONS,
    value: sentences
  });
  await speech.demandKey(0);
  return Promise.resolve();
};

fns.stop = () => {
  speech.stop();
};

fns.tabClosed = tabId => {
  console.log("tabClosed", tabId);
  const state = store.getState();
  if (state.player.playingTabId === tabId) fns.stop();
};

browserAPI.runtime.onMessage.addListener(
  async (request, sender, sendResponse) => {
    console.log("Pericles.background.onMessage.request", request);
    if (request.type && request.type === "event") {
      reportGA({
        category: request.data || "",
        action: request.action || "clicked",
        label: request.url || ""
      });
      // window.ga(
      // "send",
      // "event",
      // request.data || "",
      // request.action || "clicked",
      // request.url || ""
      // );
    } else if (request.message) {
      let out;
      try {
        const fn = fns[request.message];
        let params = request.params;
        if (request.message === "tabClosed") params = sender.tab.id;

        // console.log("Pericles.background.onMessage(message, fn)", request, fn);
        out = await fn.call(null, params);
        // console.log("Pericles.background.onMessage.sendResponse(out)", out);
      } catch (e) {
        console.error("Pericles.background.onMessage", e);
        out = "error";
      }

      sendResponse(out);
    }
  }
);

browserAPI.runtime.onInstalled.addListener(async details => {
  console.log("Pericles.popup.onInstalled", details);
  if (details && details.reason === "install") {
    const version = browserAPI.runtime.getManifest().version;
    const tab = await browserAPI.tabs.create({
      url: INSTALLED_URL + version,
      active: true
    });

    if (tab) {
      await window.update(tab.windowId, {
        focused: true
      });
    }
  }
});

browserAPI.contextMenus.create({
  id: "pericles-utter",
  title: "Speak.. ",
  contexts: ["selection"]
});

browserAPI.contextMenus.create({
  id: "pericles-stop",
  title: "Stop!",
  contexts: ["selection"]
});

browserAPI.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId === "pericles-utter") {
    const text = info.selectionText || "";
    if (text.length) {
      console.log("Pericles uttering: ", {
        type: "utter",
        data: text
      });
      await fns.utter(text);
    } else {
      console.log("no text to utter!");
    }
  } else if (info.menuItemId === "pericles-stop") {
    await fns.stop();
  }
});

const uninstallURL =
  "https://pericles.alexandrucalin.me/extension-uninstall?domain=&utm_medium=internal&utm_campaign=extensionUninstall";
browserAPI.runtime.setUninstallURL(uninstallURL);

const runPlay = async () => {
  const state = store.getState();
  const activeTabId = await getContentTabId();
  console.log("activeTabId & store", activeTabId, state);
  if (
    state.player.playingTabId !== 0 &&
    state.player.playingTabId !== activeTabId
  ) {
    await speech.reset();
  } else {
    if (state.player.status === PLAYER.STATUS.IS_PAUSED) {
      console.log("runPlay.resuming");
      speech.resume();
    } else {
      await speech.demand();
    }
  }
};

const runNext = async () => {
  // console.log("runNext");
  await speech.next();
};

const runPevious = async () => {
  // console.log("runNext");
  await speech.prev();
};

const runStop = () => {
  // console.log("runStop");
  speech.stop();
};

const runHalt = () => {
  speech.halt();
};

const runPause = () => {
  // console.log("runPause");
  speech.pause();
};

const runSetHotkeys = async stateUpdate => {
  await storage.set(stateUpdate.key, JSON.stringify(stateUpdate.hotkeys));
};

const runSetSettings = async stateUpdate => {
  const state = store.getState();
  const settings = ["volume", "pitch", "rate", "voice"];
  settings.forEach(async setting => {
    if (Object.keys(stateUpdate).includes(setting))
      await storage.set(setting, stateUpdate[setting]);
  });
  if (state.player.status === PLAYER.STATUS.IS_PLAYING) await speech.replay();
};

const runSetVoices = async stateUpdate => {
  getSavedItem(["voice"], SETTINGS.ACTION.UPDATE);
};

const runSetOtherSettings = async stateUpdate => {
  const settings = ["autoscroll", "disableHotkeys", "highlightColor"];
  settings.forEach(async setting => {
    if (Object.keys(stateUpdate).includes(setting))
      await storage.set(setting, stateUpdate[setting]);
  });
};

const setHotkeysEpic = action$ =>
  action$.pipe(
    ofType(SETTINGS.ACTION.SET_HOTKEYS),
    tap(runSetHotkeys),
    ignoreElements()
  );

const setSettingsEpic = action$ =>
  action$.pipe(
    ofType(SETTINGS.ACTION.UPDATE),
    tap(runSetSettings),
    ignoreElements()
  );

const setOtherSettingsEpic = action$ =>
  action$.pipe(
    ofType(SETTINGS.ACTION.OTHER_UPDATE),
    tap(runSetOtherSettings),
    ignoreElements()
  );

const playEpic = action$ =>
  action$.pipe(ofType(PLAYER.EPIC.PLAY), tap(runPlay), ignoreElements());

const stopEpic = action$ =>
  action$.pipe(ofType(PLAYER.EPIC.STOP), tap(runStop), ignoreElements());

const haltEpic = action$ =>
  action$.pipe(ofType(PLAYER.EPIC.HALT), tap(runHalt), ignoreElements());

const pauseEpic = action$ =>
  action$.pipe(ofType(PLAYER.EPIC.PAUSE), tap(runPause), ignoreElements());

const nextEpic = action$ =>
  action$.pipe(ofType(PLAYER.EPIC.NEXT), tap(runNext), ignoreElements());

const prevEpic = action$ =>
  action$.pipe(ofType(PLAYER.EPIC.PREV), tap(runPevious), ignoreElements());

const setVoicesEpic = action$ =>
  action$.pipe(
    ofType(PLAYER.ACTION.SET_VOICES),
    tap(runSetVoices),
    ignoreElements()
  );

observableMiddleware.run(playEpic);
observableMiddleware.run(stopEpic);
observableMiddleware.run(haltEpic);
observableMiddleware.run(pauseEpic);
observableMiddleware.run(nextEpic);
observableMiddleware.run(prevEpic);
observableMiddleware.run(setSettingsEpic);
observableMiddleware.run(setHotkeysEpic);
observableMiddleware.run(setOtherSettingsEpic);
observableMiddleware.run(setVoicesEpic);

store.subscribe(() => {
  const state = store.getState();
  console.log("something changed in store", state);
});

const getEnglishVoiceKey = voices => {
  let index = -1;
  const testVoices = ["google us english", "english"];
  testVoices.forEach(testVoice => {
    if (index === -1)
      index = voices.findIndex(
        voice => voice.text.toLocaleLowerCase().indexOf(testVoice) !== -1
      );
  });
  if (index === -1) index = 0;
  return index;
};

const getSavedItem = (items, type) => {
  const state = store.getState();
  items.forEach(async setting => {
    const val = await storage.get(setting);
    if (val !== undefined) {
      const updatedState = {
        type: type
      };
      updatedState[setting] = val;
      store.dispatch(updatedState);
    } else {
      if (setting === "voice") {
        const voiceKey = getEnglishVoiceKey(state.player.voices);
        store.dispatch({
          type: SETTINGS.ACTION.UPDATE,
          voice: voiceKey
        });
      } else {
        await storage.set(setting, state[setting]);
      }
    }
  });
};

const getSavedHotkey = items => {
  items.forEach(async setting => {
    const state = store.getState();
    const val = await storage.get(setting);
    if (val !== undefined) {
      store.dispatch({
        type: SETTINGS.ACTION.SET_HOTKEYS,
        key: setting,
        hotkeys: JSON.parse(val)
      });
    } else {
      await storage.set(setting, JSON.stringify(state.hotkeys[setting]));
    }
  });
};

const setVoices = voices => {
  console.log("browser.tts.getVoices", voices);
  const groupMap = [];
  let firstWord;
  let groupId;
  let nameSplit = "";
  voiceNames = voices.map((item, key) => {
    nameSplit = (item.voiceName || item.name)
      .replace(/\((.*)\)/, "")
      .trim()
      .split(/\s+/);
    if (nameSplit.length > 1 && !IS_FIREFOX) {
      firstWord = nameSplit[0];
      groupId = groupMap.indexOf(firstWord);
      if (groupId === -1) {
        groupMap.push(firstWord);
        groupId = groupMap.length - 1;
      }
    }
    const out = {
      id: key,
      lang: item.lang,
      countryCode: item.lang,
      text: item.voiceName || item.name,
      groupName: groupMap[groupId]
    };
    const compoundLangRegex = new RegExp("[a-z]{2}-[a-z]{2}", "i");
    if (compoundLangRegex.test(item.lang))
      out.countryCode = item.lang.slice(3).toLocaleUpperCase();
    else out.countryCode = item.lang.toLocaleUpperCase();

    out.shortTitle = out.text;
    if (out.text.split(/\s+/).length > 1 && !IS_FIREFOX)
      out.shortTitle = out.text
        .split(/\s+/)
        .splice(1)
        .join(" ");

    return out;
  });

  // voiceNames.unshift({
  // id: 0,
  // lang: "en-US",
  // countryCode: "US",
  // text: "Microsoft David Desktop - English",
  // shortTitle: "David Desktop - English",
  // groupName: "Microsoft"
  // });

  // console.log("voiceNames", voiceNames);
  store.dispatch({
    type: PLAYER.ACTION.SET_VOICES,
    value: voiceNames
  });
};

const getBrowserAPIVoices = () => {
  if (browserAPI.tts)
    browserAPI.tts.getVoices(async voices => {
      setVoices(voices);
    });
  else {
    const voices = speechSynthesis.getVoices();
    setVoices(voices);
  }
};

getBrowserAPIVoices();

speechSynthesis.onvoiceschanged = getBrowserAPIVoices;

getSavedItem(["volume", "pitch", "rate"], SETTINGS.ACTION.UPDATE);
getSavedItem(
  ["autoscroll", "disableHotkeys", "highlightColor"],
  SETTINGS.ACTION.OTHER_UPDATE
);

getSavedHotkey(["play", "stop", "next", "prev"]);
