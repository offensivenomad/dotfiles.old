import store from "../store/store";
import {
  playerUpdateDispatch,
  parserUpdateSectionsDipsatch
} from "../store/dispatch";
import { mpToContent } from "../../src/lib/mp/mp";
import { PLAYER } from "../../src/core/types";
const synth = window.speechSynthesis;

const getVoiceByKey = async voiceKey => {
  return new Promise(async (resolve, reject) => {
    const voices = await synth.getVoices();
    resolve(voices[voiceKey]);
  });
};

const self = {
  msg: new SpeechSynthesisUtterance(),
  lang: "en-GB",
  charIndex: 0,
  oldCharIndex: 0,

  playingTabHasClosed: async tabId => {
    const state = store.getState();
    if (tabId === state.player.playingTabId) {
      console.log("Pericles.speech.playingTabHasClosed. yes", tabId);
      await self.reset();
    }
  },

  demandKey: async key => {
    // console.log("Pericles.speech.demandKey(key)", key);
    playerUpdateDispatch({
      status: PLAYER.STATUS.IS_READY,
      currentSection: key
    });
    synth.cancel();
    setTimeout(async () => {
      await self.demand();
    }, 100);
  },

  demand: async () => {
    const state = store.getState();
    const sections = [...state.player.sections].slice(
      state.player.currentSection
    );
    console.log("Pericles.speech.demand()", state.player.currentSection);
    self.play();
    await self.read(sections, async () => {
      console.log("finished reading");
      playerUpdateDispatch({
        status: PLAYER.STATUS.IS_READY
      });
      const webParserType = await mpToContent("webParserType");
      console.log("Pericles.speech.demand().done", webParserType);
      if (
        webParserType.response === "googleDoc" ||
        webParserType.response === "viewerDoc"
      ) {
        const out = await mpToContent("scrollToAdjacentPage");
        console.log("Pericles.speech.scrollToAdjacentPage", out);
        if (out.response === "next") {
          await self.start();
        }
      }
    });
  },

  readNextSentence: async (sentences, done) => {
    const endState = store.getState();
    const nextSentences = sentences.slice(1);
    if (
      nextSentences.length &&
      endState.player.status !== PLAYER.STATUS.IS_STOPPED
    ) {
      console.log(
        "Pericles.speech.read().msg.onend.going to nextSentence",
        nextSentences,
        endState.player.status
      );
      playerUpdateDispatch({
        currentSection: endState.player.currentSection + 1
      });
      await self.read(nextSentences, done);
    } else {
      if (done) done();
    }
  },

  read: async (sentences, done) => {
    // console.log("read", sentences);
    const state = store.getState();
    self.charIndex = 0;
    self.oldCharIndex = 0;

    if (!sentences.length && done) done();
    const sentence = sentences[0];
    // console.log("Pericles.speech.read().sentence", sentence);
    if (!sentence || !sentence.text) {
      self.readNextSentence(sentences, done);
    }

    if (state.player.status === PLAYER.STATUS.IS_STOPPED) {
      // console.log("Pericles.speech.read().stop detected");
      if (done) done();
      return;
    }

    self.msg = new SpeechSynthesisUtterance();
    self.msg.lang = self.lang;
    const voiceKey = state.player.settings.voice;
    const voice = await getVoiceByKey(voiceKey);
    // console.log("Pericles.speech.read().msg.voice", voice);
    if (voice) self.msg.voice = voice;
    self.msg.text = sentence.text;
    self.msg.volume = state.player.settings.volume;
    self.msg.pitch = state.player.settings.pitch;
    self.msg.rate = state.player.settings.rate;

    // console.log("Pericles.speech.read().msg", self.msg);
    synth.speak(self.msg);
    self.msg.onmark = e => {
      // console.log("Pericles.speech.msg.onmark", e);
    };

    self.msg.onword = e => {
      // console.log("Pericles.speech.msg.onword", e);
      if (e.charIndex !== self.oldCharIndex || e.charIndex === 0) {
        // self.wordTracker(charIndex)
        self.charIndex++;
      }
      self.oldCharIndex = e.charIndex;
    };

    self.msg.onboundary = e => {
      // console.log("Pericles.speech.msg.onboundary", e);
      if (e.charIndex !== self.oldCharIndex || e.charIndex === 0) {
        // self.wordTracker(charIndex)
        self.charIndex++;
      }
      self.oldCharIndex = e.charIndex;
    };

    self.msg.onend = async () => {
      const endState = store.getState();
      // console.log("Pericles.speech.msg.onend", endState);
      if (
        [PLAYER.STATUS.IS_READY, PLAYER.STATUS.IS_STOPPED].includes(
          endState.player.status
        )
      ) {
        // console.log("Pericles.speech.read.msg.onend.isStopped");
        return;
      }

      self.readNextSentence(sentences, done);
    };

    self.msg.onstart = async e => {
      // console.log("Pericles.speech.msg.onstart", e, sentence);
      // await mpToContent("highlightSentence", self.sectionKey);
    };

    self.msg.onerror = e => {
      // console.log("Pericles.speech.msg.onerror", e);
    };
  },

  reset: async () => {
    self.stop();
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        parserUpdateSectionsDipsatch([]);
        resolve(true);
      }, 100);
    });
  },

  start: async () => {
    // console.log("Pericles.speech.start()");
    self.stop();
    return new Promise((resolve, reject) => {
      setTimeout(async () => {
        await self.reset();
        await mpToContent("getSections");
        resolve();
      }, 500);
    });
  },

  play: () => {
    // console.log("Pericles.speech.play()");
    synth.cancel();
    playerUpdateDispatch({
      status: PLAYER.STATUS.IS_PLAYING
    });
  },

  replay: async () => {
    playerUpdateDispatch({
      status: PLAYER.STATUS.IS_READY
    });
    synth.cancel();
    setTimeout(async () => {
      await self.demand();
    }, 100);
  },

  prev: async () => {
    const state = store.getState();
    playerUpdateDispatch({
      status: PLAYER.STATUS.IS_READY,
      currentSection:
        state.player.currentSection > 0
          ? state.player.currentSection - 1
          : state.player.currentSection
    });
    synth.cancel();
    console.log("Pericles.speech.prev()", state.player.currentSection);

    setTimeout(async () => {
      await self.demand();
    }, 100);
  },

  next: async () => {
    const state = store.getState();
    const nextSection =
      state.player.currentSection < state.player.sections.length - 1
        ? state.player.currentSection + 1
        : state.player.currentSection;
    playerUpdateDispatch({
      status: PLAYER.STATUS.IS_READY,
      currentSection: nextSection
    });
    console.log("Pericles.speech.next()", nextSection);
    synth.cancel();
    setTimeout(async () => {
      await self.demand();
    }, 100);
  },

  stop: () => {
    console.log("Pericles.speech.stop()");
    playerUpdateDispatch({
      status: PLAYER.STATUS.IS_STOPPED,
      currentSection: 0,
      playingTabId: 0
    });
    synth.cancel();
  },

  halt: async () => {
    // console.log("Pericles.speech.halt()");
    playerUpdateDispatch({
      status: PLAYER.STATUS.IS_READY,
      currentSection: 0
    });
    synth.cancel();
  },

  pause: () => {
    // console.log("Pericles.speech.pause()");
    playerUpdateDispatch({
      status: PLAYER.STATUS.IS_PAUSED
    });
    synth.pause();
  },

  resume: () => {
    // console.log("Pericles.speech.resume()");
    playerUpdateDispatch({
      status: PLAYER.STATUS.IS_PLAYING
    });
    synth.resume();
  }
};

export default self;
