import store from "./store";
import { PLAYER, PARSER } from "../../src/core/types";

export const playerUpdateDispatch = props => {
  const obj = Object.assign(
    {
      type: PLAYER.ACTION.UPDATE
    },
    props
  );
  // console.log("playerUpdateDispatch", obj);
  store.dispatch(obj);
};

export const parserUpdateSectionsDipsatch = sections => {
  store.dispatch({
    type: PARSER.ACTION.SET_SECTIONS,
    value: sections
  });
};
