import React, { Component } from "react";
import {
  TextField,
  Typography,
  FormControlLabel,
  FormGroup,
  Switch
} from "@material-ui/core";
import { SETTINGS } from "../../../core/types";
import { connect } from "react-redux";

class HotkeysComponent extends Component {
  otherSettingsChanged = (key, val) => {
    this.props.onOtherSettingsChanged(key, val);
  };

  onPlayChanged = e => {
    console.log("onPlayChanged", e.target.value);
  };

  onKeyFocus = type => {
    this.props.onHotkeyFocus(type);
  };

  getKeyCombo = key => {
    return this.props.hotkeys[key]
      .map(playKey => {
        if (playKey.key.trim().length) {
          return playKey.key.toLocaleUpperCase();
        } else {
          return playKey.code.toLocaleUpperCase();
        }
      })
      .join("+");
  };

  render() {
    const playDefault = this.getKeyCombo("play");
    const stopDefault = this.getKeyCombo("stop");
    const nextDefault = this.getKeyCombo("next");
    const prevDefault = this.getKeyCombo("prev");
    console.log("playDefault", playDefault);
    return (
      <>
        <form noValidate autoComplete="off">
          <Typography>Customize your hotkeys</Typography>
          <div>
            <TextField
              inputProps={{ readOnly: true }}
              id="filled-basic"
              label="play/pause"
              variant="filled"
              onFocus={(e: any) => {
                this.onKeyFocus("play");
              }}
              onBlur={() => {
                this.onKeyFocus("");
              }}
              value={playDefault}
            />
          </div>
          <div>
            <TextField
              id="filled-basic"
              inputProps={{ readOnly: true }}
              label="stop"
              variant="filled"
              onBlur={() => {
                this.onKeyFocus("");
              }}
              onFocus={() => {
                this.onKeyFocus("stop");
              }}
              value={stopDefault}
            />
          </div>
          <div>
            <TextField
              id="filled-basic"
              inputProps={{ readOnly: true }}
              onBlur={() => {
                this.onKeyFocus("");
              }}
              onFocus={() => {
                this.onKeyFocus("next");
              }}
              label="next"
              variant="filled"
              value={nextDefault}
            />
          </div>
          <div>
            <TextField
              inputProps={{ readOnly: true }}
              id="filled-basic"
              label="prev"
              onBlur={() => {
                this.onKeyFocus("");
              }}
              onFocus={() => {
                this.onKeyFocus("prev");
              }}
              variant="filled"
              value={prevDefault}
            />
          </div>
        </form>
        <FormGroup row>
          <FormControlLabel
            control={
              <Switch
                checked={this.props.disableHotkeys}
                color="primary"
                onChange={(event, value) => {
                  this.otherSettingsChanged("disableHotkeys", value);
                }}
                inputProps={{ "aria-label": "primary checkbox" }}
                value="1"
              />
            }
            label="Disable hotkeys"
          />
        </FormGroup>
      </>
    );
  }
}

const mapStateToPros = state => {
  return {
    disableHotkeys: state.disableHotkeys,
    hotkeys: state.hotkeys
  };
};

const mapDispatchToProps = dispatch => {
  return {
    onOtherSettingsChanged: (key, val) => {
      const updatedState = { type: SETTINGS.ACTION.OTHER_UPDATE };
      updatedState[key] = val;
      return dispatch(updatedState);
    },
    onHotkeyFocus: hotkey => {
      return dispatch({
        type: SETTINGS.ACTION.HOTKEY_FOCUS,
        hotkeyFocus: hotkey
      });
    }
  };
};

export default connect(mapStateToPros, mapDispatchToProps)(HotkeysComponent);
