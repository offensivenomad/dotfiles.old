import { PLAYER, PARSER, SETTINGS, CONTENT, APP } from "../core/types";

const initialState = {
  // app
  showSettings: false,
  hotkeyFocus: "",
  hotkeys: {
    play: [
      {
        which: 75,
        key: "k",
        code: "keyK"
      }
    ],
    next: [
      {
        which: 78,
        key: "n",
        code: "keyN"
      }
    ],
    prev: [
      {
        which: 80,
        key: "p",
        code: "keyP"
      }
    ],
    stop: [
      {
        which: 74,
        key: "j",
        code: "keyJ"
      }
    ]
  },

  player: {
    settings: {
      volume: 0.9,
      pitch: 1,
      rate: 1,
      voice: 1
    },
    sections: [],
    currentSection: 0,
    status: 0,
    voices: ["loading voices.."],
    playingTabId: 0
  },

  // other settings
  autoscroll: true,
  disableHotkeys: false,
  highlightColor: "fffc02",

  // meta
  skipAnimate: false
};

const reducer = (state = initialState, action) => {
  const newState = JSON.parse(JSON.stringify(state));

  switch (action.type) {
    case APP.ACTION.UPDATE:
      const appUpdates = ["showSettings"];
      appUpdates.forEach(update => {
        if (action[update] !== undefined) newState[update] = action[update];
      });
      break;

    case PLAYER.ACTION.SET_VOICES:
      newState.player.voices = action.value;
      break;

    // Parser
    case PARSER.ACTION.SET_SECTIONS:
      newState.player.sections = action.value;
      break;

    // Player
    case PLAYER.ACTION.UPDATE:
      const updates = ["currentSection", "status", "playingTabId"];
      updates.forEach(update => {
        if (action[update] !== undefined)
          newState.player[update] = action[update];
      });
      break;

    case PLAYER.ACTION.CURRENT_SECTION:
      newState.player.currentSection = action.value;
      break;

    case PLAYER.ACTION.LOADING:
      newState.player.status = PLAYER.STATUS.IS_LOADING;
      break;

    case PLAYER.ACTION.ERROR:
      newState.player.status = PLAYER.STATUS.IS_ERROR;
      break;

    case PLAYER.ACTION.TAB_ID:
      newState.player.playingTabId = action.tabId;
      break;

    case CONTENT.ACTION.SKIP_ANIMATE:
      newState.skipAnimate = action.value;
      break;

    case SETTINGS.ACTION.UPDATE:
      const settings = ["voice", "volume", "pitch", "rate"];
      settings.forEach(update => {
        if (action[update] !== undefined)
          newState.player.settings[update] = action[update];
      });
      break;

    case SETTINGS.ACTION.OTHER_UPDATE:
      const otherSettings = ["autoscroll", "highlightColor", "disableHotkeys"];
      otherSettings.forEach(update => {
        if (action[update] !== undefined) newState[update] = action[update];
      });
      break;
    case SETTINGS.ACTION.HOTKEY_FOCUS:
      newState.hotkeyFocus = action.hotkeyFocus;
      break;
    case SETTINGS.ACTION.SET_HOTKEYS:
      newState.hotkeys[action.key] = action.hotkeys;
      break;

    default:
  }

  return newState;
};

export default reducer;
