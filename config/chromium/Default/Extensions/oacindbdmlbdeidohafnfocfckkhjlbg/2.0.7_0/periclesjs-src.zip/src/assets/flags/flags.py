import urllib
import urllib.request
import json
import uuid

response = urllib.request.urlopen('https://restcountries.eu/rest/v2/all')
data = json.load(response)

newData = {}

for country in data:
  newData[country.get('name')] = {'code': country.get('callingCodes')[0], 'flag': country.get('alpha3Code').lower() + '.svg'}
  jsons = json.dumps(newData)
  urllib.request.urlretrieve(country.get('flag'), '/Users/flavius/Desktop/flags/' + country.get('alpha3Code').lower() + '.svg')
  with open('/Users/flavius/Desktop/flags/countries.json', 'w') as outfile:
    json.dump(newData, outfile)
