import React, { Component } from "react";
import ReactTestUtils from "react-dom/test-utils";

import { Grid, IconButton, withStyles } from "@material-ui/core";
import {
  PlayArrowSharp,
  StopSharp,
  SkipPreviousSharp,
  SkipNextSharp,
  PauseSharp
} from "@material-ui/icons";
import { connect } from "react-redux";
import { mpToContent } from "../../lib/mp/mp";
import { PLAYER, PARSER, SETTINGS } from "../../core/types";

const styles = theme => ({
  fbutton: {
    border: "1px solid #dfdfdf",
    borderBottom: "none"
  },
  bigBtn: {
    padding: 16
  },
  smallBtn: {
    padding: 6
  },
  button: {
    border: "1px solid #dfdfdf"
  },
  flatButton: {
    borderRadius: 0,
    width: "100%"
  },
  activeButton: {
    backgroundColor: theme.palette.primary.main
  },
  largeIcon: {
    height: 30,
    width: 30
  }
});

class PlayerComponent extends Component {
  parseState = [PLAYER.STATUS.IS_STOPPED, PLAYER.STATUS.IS_ERROR];
  playState = [PLAYER.STATUS.IS_READY, PLAYER.STATUS.IS_PAUSED];
  pauseState = [PLAYER.STATUS.IS_PLAYING];
  t = 0;
  playRef = React.createRef();
  stopRef = React.createRef();
  nextRef = React.createRef();
  prevRef = React.createRef();

  componentDidMount() {
    this.registerKeyUpListener();
  }

  hotkeyEvents = {
    play: () => {
      ReactTestUtils.Simulate.click(this.playRef.current);
    },
    stop: () => {
      ReactTestUtils.Simulate.click(this.stopRef.current);
    },
    next: () => {
      ReactTestUtils.Simulate.click(this.nextRef.current);
    },
    prev: () => {
      ReactTestUtils.Simulate.click(this.prevRef.current);
    }
  };

  registerKeyUpListener = () => {
    document.addEventListener("keyup", e => {
      clearTimeout(this.t);
      this.t = setTimeout(() => {
        console.log("onKeyUp", e);
        if (this.props.hotkeyFocus) {
          const hotkeys = [];
          const { which, key, code } = e;
          hotkeys.push({ which, key, code });
          this.props.onUpdateHotkeyAndResetFocus(
            this.props.hotkeyFocus,
            hotkeys
          );
        } else {
          const find = Object.keys(this.props.hotkeys).find(key => {
            console.log(this.props.hotkeys[key], key, e);
            return this.props.hotkeys[key][0].which === e.which;
          });
          if (!this.props.disableHotkeys && find && this.hotkeyEvents[find])
            this.hotkeyEvents[find]();
        }
      }, 150);
    });
  };

  playOrParse = async () => {
    if (this.parseState.includes(this.props.status)) this.parse();
    else if (this.playState.includes(this.props.status)) this.props.onPlay();
    else if (this.pauseState.includes(this.props.status)) this.props.onPause();
  };

  parse = async () => {
    this.props.onLoading();
    const timeout = new Promise(resolve => {
      let id = setTimeout(() => {
        clearTimeout(id);
        resolve({ response: false, error: "timeout" });
      }, 40000);
    });

    try {
      const st = await Promise.race([mpToContent("getSections"), timeout]);
      // const st = await mpToContent("getSections");
      console.log("getSections.response", st);
      if (st.response !== true) this.props.onError();
      if (st.tabId) this.props.onSetPlayingTabId(st.tabId);
      console.log("parse.succes", st);
    } catch (e) {
      console.log("parse.error");
      this.props.onError();
    }
  };

  render() {
    const { classes } = this.props;

    const isDisabledPlay = this.props.status === PLAYER.STATUS.IS_LOADING;
    const isDisabledOther = [
      PLAYER.STATUS.IS_STOPPED,
      PLAYER.STATUS.IS_LOADING,
      PLAYER.STATUS.IS_ERROR
    ].includes(this.props.status);

    let playIcon = <PlayArrowSharp className={classes.largeIcon} />;

    if (
      [PLAYER.STATUS.IS_READY, PLAYER.STATUS.IS_PAUSED].includes(
        this.props.status
      )
    ) {
      playIcon = <PlayArrowSharp className={classes.largeIcon} />;
    } else if (this.props.status === PLAYER.STATUS.IS_PLAYING) {
      playIcon = <PauseSharp className={classes.largeIcon} />;
    }

    const playButton = (
      <IconButton
        className={`${classes.flatButton} ${classes.bigBtn}`}
        disabled={isDisabledPlay}
        onClick={this.playOrParse}
        color="secondary"
        ref={this.playRef}
      >
        {playIcon}
      </IconButton>
    );

    let html = (
      <>
        <Grid container align="center">
          <Grid
            xs={9}
            className={`${classes.fbutton} ${classes.activeButton}`}
            item
          >
            {playButton}
          </Grid>
          <Grid
            xs={3}
            item
            className={`${classes.fbutton}`}
            style={{ borderLeft: "none" }}
          >
            <IconButton
              disabled={isDisabledOther}
              onClick={this.props.onStop}
              className={`${classes.flatButton} ${classes.bigBtn}`}
              color="primary"
              ref={this.stopRef}
            >
              <StopSharp className={classes.largeIcon} />
            </IconButton>
          </Grid>
        </Grid>
        <Grid container align="center">
          <Grid item xs={6} className={classes.button}>
            <IconButton
              className={`${classes.flatButton} ${classes.smallBtn}`}
              disabled={isDisabledOther}
              onClick={this.props.onPrev}
              color="primary"
              size="small"
              ref={this.prevRef}
            >
              <SkipPreviousSharp className={classes.largeIcon} />
            </IconButton>
          </Grid>
          <Grid
            item
            xs={6}
            className={classes.button}
            style={{ borderLeft: "none" }}
          >
            <IconButton
              className={`${classes.flatButton} ${classes.smallBtn}`}
              disabled={isDisabledOther}
              onClick={this.props.onNext}
              ref={this.nextRef}
              color="primary"
              size="small"
            >
              <SkipNextSharp className={classes.largeIcon} />
            </IconButton>
          </Grid>
        </Grid>
      </>
    );
    return html;
  }
}

const mapStateToProps = state => {
  return {
    sections: state.player.sections,
    status: state.player.status,
    hotkeyFocus: state.hotkeyFocus,
    hotkeys: state.hotkeys,
    disableHotkeys: state.disableHotkeys
  };
};

const mapDispatchToProps = dispatch => {
  return {
    onSetSections: sections => {
      dispatch({ type: PARSER.ACTION.SET_SECTIONS, value: sections });
    },
    onLoading: () => {
      dispatch({ type: PLAYER.ACTION.LOADING });
    },
    onError: () => {
      dispatch({ type: PLAYER.ACTION.ERROR });
    },
    onPlay: () => {
      dispatch({ type: PLAYER.EPIC.PLAY });
    },
    onStop: () => {
      dispatch({ type: PLAYER.EPIC.STOP });
    },
    onPause: () => {
      dispatch({ type: PLAYER.EPIC.PAUSE });
    },
    onNext: () => {
      dispatch({ type: PLAYER.EPIC.NEXT });
    },
    onPrev: () => {
      dispatch({ type: PLAYER.EPIC.PREV });
    },
    onSetPlayingTabId: id => {
      dispatch({ type: PLAYER.ACTION.TAB_ID, tabId: id });
    },
    onUpdateHotkeyAndResetFocus: (key, hotkeys) => {
      return dispatch({
        type: SETTINGS.ACTION.SET_HOTKEYS,
        hotkeyFocus: "",
        key: key,
        hotkeys: hotkeys
      });
    }
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(styles)(PlayerComponent));
