export const INTERVAL_WORD = 0.28;
export const INTERVAL_SPEAKING_SERVICE_DELAY = 0.4;
export const GA_TRACKING_ID = "UA-25965793-6";
export const GA_CLIENT_ID = "";
export const IS_FIREFOX = typeof InstallTrigger !== "undefined";
