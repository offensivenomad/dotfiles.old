import React, { Component } from "react";
import { connect } from "react-redux";
import { SETTINGS } from "../../core/types";
import {
  FormGroup,
  TextField,
  Box,
  Grid,
  Typography,
  Slider,
  FormControlLabel,
  withStyles,
  Switch,
  InputAdornment
} from "@material-ui/core";
import { Autocomplete } from "@material-ui/lab";
import { FlagSharp } from "@material-ui/icons";
import * as countriesFlags from "../../core/countries.json";

// country flags
import GB from "../../assets/flags/gbr.svg";
import US from "../../assets/flags/usa.svg";
import DE from "../../assets/flags/deu.svg";
import ES from "../../assets/flags/esp.svg";
import FR from "../../assets/flags/fra.svg";
import IN from "../../assets/flags/ind.svg";
import ID from "../../assets/flags/ind.svg";
import IT from "../../assets/flags/ita.svg";
import JP from "../../assets/flags/jpn.svg";
import KR from "../../assets/flags/kor.svg";
import NL from "../../assets/flags/nld.svg";
import PL from "../../assets/flags/pol.svg";
import BR from "../../assets/flags/bra.svg";
import RU from "../../assets/flags/rus.svg";
import CN from "../../assets/flags/chn.svg";
import HK from "../../assets/flags/hkg.svg";
import TW from "../../assets/flags/twn.svg";
import RO from "../../assets/flags/rou.svg";

const flags = {
  GB: GB,
  US: US,
  DE: DE,
  ES: ES,
  FR: FR,
  IN: IN,
  ID: ID,
  IT: IT,
  JP: JP,
  KR: KR,
  NL: NL,
  PL: PL,
  BR: BR,
  RU: RU,
  CN: CN,
  HK: HK,
  TW: TW,
  RO: RO
};

const styles = theme => ({
  text: {
    fontSize: 12
  },
  flagImg: {
    width: 30
  },
  flagOptionImg: {
    marginRight: 8
  }
});

let t;
class SettingsComponent extends Component {
  settingsChanged = (key, val) => {
    clearTimeout(t);
    t = setTimeout(() => {
      this.props.onSettingChanged(key, val);
    }, 300);
  };

  otherSettingsChanged = (key, val) => {
    this.props.onOtherSettingsChanged(key, val);
  };

  voiceChanged = (event, value, key) => {
    console.log("voiceChanged", event, value, key);
    this.props.onSettingChanged("voice", value.id);
  };

  render() {
    console.log("countriesFlags", countriesFlags);
    console.log("flag GB", GB);
    const { classes } = this.props;
    const voice = this.props.voices[this.props.voice];
    return (
      <>
        <Box mt={1} mb={1}>
          <Autocomplete
            size="small"
            id="change-voice-combo"
            options={this.props.voices}
            getOptionLabel={option => option.shortTitle}
            groupBy={option => option.groupName}
            onChange={this.voiceChanged}
            defaultValue={voice}
            style={{ width: "100%" }}
            renderOption={option => {
              return (
                <>
                  {flags[option.countryCode] ? (
                    <img
                      src={flags[option.countryCode]}
                      alt={option.countryCode}
                      className={`${classes.flagImg} ${classes.flagOptionImg}`}
                    />
                  ) : (
                    <FlagSharp />
                  )}
                  {option.shortTitle}
                </>
              );
            }}
            renderInput={params => {
              params.InputProps.startAdornment = (
                <InputAdornment position="start">
                  {voice && flags[voice.countryCode] ? (
                    <img
                      src={flags[voice.countryCode]}
                      alt={voice.countryCode}
                      className={classes.flagImg}
                    />
                  ) : (
                    <FlagSharp />
                  )}
                </InputAdornment>
              );
              return (
                <TextField
                  {...params}
                  label="Voice & Language"
                  variant="outlined"
                  fullWidth
                />
              );
            }}
          />
        </Box>
        <Grid container>
          <Grid item xs={12}>
            <Typography
              component="span"
              className={classes.text}
              id="discrete-slider"
              gutterBottom
            >
              Volume
            </Typography>
            <Slider
              onChange={(event, value) => {
                this.settingsChanged("volume", value);
              }}
              defaultValue={this.props.volume}
              aria-labelledby="discrete-slider"
              valueLabelDisplay="auto"
              step={0.1}
              scale={x => x * 100}
              marks
              min={0.1}
              max={1}
            />
          </Grid>
          <Grid item xs={12}>
            <Typography
              component="span"
              className={classes.text}
              id="discrete-slider"
              gutterBottom
            >
              Pitch
            </Typography>
            <Slider
              onChange={(event, value) => {
                this.settingsChanged("pitch", value);
              }}
              defaultValue={this.props.pitch}
              aria-labelledby="discrete-slider"
              valueLabelDisplay="auto"
              step={0.1}
              marks
              min={0.1}
              max={2}
            />
          </Grid>
          <Grid item xs={12}>
            <Typography
              component="span"
              className={classes.text}
              id="discrete-slider"
              gutterBottom
            >
              Speed
            </Typography>
            <Slider
              onChange={(event, value) => {
                this.settingsChanged("rate", value);
              }}
              defaultValue={this.props.rate}
              aria-labelledby="discrete-slider"
              valueLabelDisplay="auto"
              step={0.1}
              marks
              min={0.1}
              max={3.5}
            />
          </Grid>
        </Grid>
        <FormGroup row>
          <FormControlLabel
            control={
              <Switch
                checked={this.props.autoscroll}
                color="primary"
                onChange={(event, value) => {
                  this.otherSettingsChanged("autoscroll", value);
                }}
                inputProps={{ "aria-label": "primary checkbox" }}
                value="1"
              />
            }
            label="Auto-scroll"
          />
        </FormGroup>
      </>
    );
  }
}

const mapStateToPros = state => {
  return {
    showSettings: state.showSettings,

    voice: state.player.settings.voice,
    voices: state.player.voices,
    volume: state.player.settings.volume,
    pitch: state.player.settings.pitch,
    rate: state.player.settings.rate,

    autoscroll: state.autoscroll
  };
};

const mapDispatchToProps = dispatch => {
  return {
    onSettingChanged: (key, val) => {
      const updatedState = { type: SETTINGS.ACTION.UPDATE };
      updatedState[key] = val;
      return dispatch(updatedState);
    },
    onOtherSettingsChanged: (key, val) => {
      const updatedState = { type: SETTINGS.ACTION.OTHER_UPDATE };
      updatedState[key] = val;
      return dispatch(updatedState);
    }
  };
};

export default connect(
  mapStateToPros,
  mapDispatchToProps
)(withStyles(styles)(SettingsComponent));
