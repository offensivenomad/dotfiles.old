import React, { Component } from "react";
import { connect } from "react-redux";
import {
  Grid,
  Typography,
  CircularProgress,
  IconButton,
  withStyles
} from "@material-ui/core";
import { PLAYER, APP } from "../../core/types";
import {
  SentimentVeryDissatisfiedRounded,
  ScheduleRounded,
  SettingsSharp,
  InfoSharp
} from "@material-ui/icons";
import messages from "../../lib/UI/UI.messages.json";
import { calcReadingTime } from "../../util/util";

const styles = theme => ({
  root: {
    height: 35
  },
  text: {
    fontSize: 13,
    fontWeight: "bold"
  },
  infoIconBoxStyle: {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    color: "#545454"
  },
  infoTextBoxStyle: {
    display: "flex",
    alignItems: "center",
    color: "#545454"
  }
});

class HeaderComponent extends Component {
  state = {
    readingTime: 0
  };

  updateReadingTime = () => {
    let readingTime = calcReadingTime(
      this.props.sections.slice(this.props.currentSection),
      this.props.rate
    );

    if (readingTime) this.setState({ readingTime: readingTime });
  };

  componentWillReceiveProps(nextProps, nextContext) {
    this.updateReadingTime();
  }

  componentDidMount() {
    this.updateReadingTime();
  }

  render() {
    const { classes } = this.props;
    let infoTextIcon = <ScheduleRounded />;
    let infoText;
    let infoTextBox = (
      <Typography className={classes.text} component="span">
        {this.state.readingTime === 0
          ? `calculating reading time..`
          : `~${this.state.readingTime}m ${messages.readTime.text}`}
      </Typography>
    );

    if (this.props.status === PLAYER.STATUS.IS_LOADING) {
      infoTextIcon = <CircularProgress size={20} />;
      infoText = messages.loading.text;
    } else if (this.props.status === PLAYER.STATUS.IS_STOPPED) {
      infoTextIcon = <InfoSharp />;
      infoText = messages.start.text;
    } else if (this.props.status === PLAYER.STATUS.IS_ERROR) {
      infoTextIcon = <SentimentVeryDissatisfiedRounded />;
      infoText = messages.failed.text;
    }

    if (
      [
        PLAYER.STATUS.IS_LOADING,
        PLAYER.STATUS.IS_STOPPED,
        PLAYER.STATUS.IS_ERROR
      ].includes(this.props.status)
    ) {
      infoTextBox = (
        <Typography className={classes.text} component="span">
          {infoText}
        </Typography>
      );
    }

    return (
      <Grid
        container
        spacing={0}
        align="center"
        alignItems="center"
        alignContent="center"
        justify="center"
        className={classes.root}
      >
        <Grid item xs={10}>
          <Grid
            container
            alignItems="center"
            alignContent="center"
            className={classes.root}
          >
            <Grid
              item
              xs={2}
              align="center"
              className={classes.infoIconBoxStyle}
            >
              {infoTextIcon}
            </Grid>
            <Grid
              item
              xs={10}
              align="left"
              className={classes.infoTextBoxStyle}
            >
              {infoTextBox}
            </Grid>
          </Grid>
        </Grid>

        <Grid item xs={2}>
          <IconButton
            onClick={() => {
              this.props.onShowSettingsChanged(!this.props.showSettings);
            }}
            size="small"
            color="primary"
          >
            <SettingsSharp />
          </IconButton>
        </Grid>
      </Grid>
    );
  }
}

const mapStateToProps = state => {
  return {
    sections: state.player.sections,
    currentSection: state.player.currentSection,
    status: state.player.status,
    showSettings: state.showSettings,
    rate: state.player.settings.rate
  };
};

const mapDispatchToProps = dispatch => {
  return {
    onShowSettingsChanged: toggle =>
      dispatch({ type: APP.ACTION.UPDATE, showSettings: toggle })
  };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(styles)(HeaderComponent));
