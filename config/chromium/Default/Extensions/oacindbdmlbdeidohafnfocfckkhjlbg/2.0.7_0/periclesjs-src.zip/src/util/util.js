import {
  INTERVAL_WORD,
  INTERVAL_SPEAKING_SERVICE_DELAY,
  GA_TRACKING_ID,
  GA_CLIENT_ID,
  IS_FIREFOX
} from "../core/constants";

/*eslint-disable */
const core = chrome || browser;
/*eslint-enable */

export const calcReadingTime = (sections, rate) => {
  if (sections && sections.length) {
    const words = sections
      .map(section =>
        section && section.text ? (section.text || "").split(" ").length : 0
      )
      .reduce((acc, val) => acc + val);

    const timeReadingWords = (words * INTERVAL_WORD) / rate;
    const timeDelayingSentences =
      INTERVAL_SPEAKING_SERVICE_DELAY * sections.length;
    return Math.ceil((timeReadingWords + timeDelayingSentences) / 60);
  } else {
    return 0;
  }
};

export const tracker = (type, data, action, url) => {
  core.runtime.sendMessage({
    type: type,
    data: data,
    action: action,
    url: url
  });
};

export const reportGA = params => {
  // Firefox 1.0+
  if (IS_FIREFOX) return false;
  try {
    const request = new XMLHttpRequest();
    let message = "";
    if (!params)
      message =
        "v=1&tid=" +
        GA_TRACKING_ID +
        "&cid= " +
        GA_CLIENT_ID +
        "&aip=1&dp=%2Fpopup" +
        "&ds=add-on&t=pageview";
    else
      message =
        "v=1&tid=" +
        GA_TRACKING_ID +
        "&cid= " +
        GA_CLIENT_ID +
        "&aip=1" +
        "&ds=add-on&t=event&ec=" +
        params.category +
        "&ea=" +
        params.action +
        "&el=" +
        params.label;

    request.open("POST", "https://www.google-analytics.com/collect", true);
    request.send(message);
  } catch (e) {
    console.log("Error sending report to Google Analytics.\n" + e);
  }
};

export function getBrowserAPI() {
  let api;
  /*eslint-disable */
  try {
    api = global.chrome || global.browser || browser;
  } catch (error) {
    api = browser;
  }
  /*eslint-enable */

  if (!api) {
    throw new Error("Browser API is not present");
  }

  return api;
}
