import { Store } from "webext-redux";
// import reducer from "./reducer";

const store = new Store();

export default store;
