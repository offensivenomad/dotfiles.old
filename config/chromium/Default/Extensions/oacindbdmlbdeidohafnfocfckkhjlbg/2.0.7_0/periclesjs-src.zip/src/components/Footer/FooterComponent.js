import React, { Component } from "react";
import SettingsComponent from "../Settings/SettingsComponent";
import { AppBar, Tab, Tabs } from "@material-ui/core";
import TabPanel from "../TabPanel/TabPanel";
import { connect } from "react-redux";
import HotkeysComponent from "../Settings/Hotkeys/HotkeysComponent";

class FooterComponent extends Component {
  state = {
    activeTab: 0
  };

  a11yProps = index => {
    return {
      id: `simple-tab-${index}`,
      "aria-controls": `simple-tabpanel-${index}`
    };
  };

  render() {
    return this.props.showSettings ? (
      <>
        <AppBar position="static" style={{ backgroundColor: "#031a54" }}>
          <Tabs
            value={this.state.activeTab}
            onChange={(e, val) => {
              this.setState({ activeTab: val });
            }}
            aria-label="simple tabs example"
          >
            <Tab label="Voice" {...this.a11yProps(0)} />
            <Tab label="Hotkeys" {...this.a11yProps(1)} />
          </Tabs>
        </AppBar>
        <TabPanel value={this.state.activeTab} index={0}>
          <SettingsComponent />
        </TabPanel>
        <TabPanel value={this.state.activeTab} index={1}>
          <HotkeysComponent />
        </TabPanel>
      </>
    ) : null;
  }
}

const mapStateToProps = state => {
  return {
    showSettings: state.showSettings
  };
};
export default connect(mapStateToProps)(FooterComponent);
