import React from "react";
import {
  Box,
  CssBaseline,
  createMuiTheme,
  ThemeProvider
} from "@material-ui/core";
import "./App.css";
import HeaderComponent from "./components/Header/HeaderComponent";
import PlayerComponent from "./components/Player/PlayerComponent";
import FooterComponent from "./components/Footer/FooterComponent";
import { tracker } from "./util/util";

const theme = createMuiTheme({
  palette: {
    primary: {
      main: "#082E8B",
      light: "#4e57bc",
      dark: "#000a5d"
    },
    secondary: {
      main: "#f0f0f0",
      light: "#ffffff",
      dark: "#cccccc"
    },
    tertiary: {
      main: "#999"
    }
  }
});
tracker("event", "open");
function App() {
  return (
    <>
      <ThemeProvider theme={theme}>
        <CssBaseline />
        <Box>
          <HeaderComponent />
          <PlayerComponent />
          <FooterComponent />
        </Box>
      </ThemeProvider>
    </>
  );
}

export default App;
