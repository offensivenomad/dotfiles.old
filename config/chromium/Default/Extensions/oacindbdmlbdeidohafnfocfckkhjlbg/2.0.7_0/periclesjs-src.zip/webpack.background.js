const TerserPlugin = require("terser-webpack-plugin");
const MiniCssExtractPlugin = require("mini-css-extract-plugin");
const path = require("path");
const mode = process.env.NODE_ENV || "development";

const config = {
  entry: {
    app: ["@babel/polyfill", "./background/background.js"]
  },
  mode: mode,
  output: {
    path: path.resolve(__dirname, "bundle"),
    filename: "background-bundle.js",
    publicPath: "/"
  },
  optimization: {
    splitChunks: {
      filename: "background-vendors.js",
      chunks: "all"
    },
    minimizer: []
  },
  module: {
    rules: [
      {
        test: /\.(js)$/,
        exclude: "/node_modules/",
        use: ["babel-loader"]
      },
      {
        test: /\.css$/,
        use: [MiniCssExtractPlugin.loader, "css-loader"]
      }
    ]
  }
};
if (mode === "production") {
  config.optimization.minimizer.push(
    new TerserPlugin({
      terserOptions: {
        compress: {
          drop_console: true
        }
      }
    })
  );
}

module.exports = config;
