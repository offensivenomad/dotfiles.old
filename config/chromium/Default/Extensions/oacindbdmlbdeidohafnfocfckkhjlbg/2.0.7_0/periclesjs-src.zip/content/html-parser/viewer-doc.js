import $ from "jquery";
import nlp from "compromise";
import googleDocsUtil from "./google-doc-utils";
import AbstractDocParser from "./abstract-doc-parser";
import {
  processHtmlText,
  senTag,
  wordTag,
  paraTag,
  identPrefix,
  removePSTags,
  getDocPageIndex,
  asyncForEach,
  createDeepCopy
} from "./html-parser.common";

let instance = null;
export default class ViewerDoc extends AbstractDocParser {
  constructor() {
    super();

    if (!instance) instance = this;

    this.type = "viewerDoc";
    this.pageIdent = ".page";
    // this.paraIdent = 'div[data-canvas-width]';
    this.paraIdent = ".textLayer";
    this.viewportIdent = "#canvasContainer";
    return instance;
  }

  async getTexts(op = "tts") {
    // console.log('Pericles.viewerDoc.getTexts()');
    return new Promise(async resolve => {
      await this.reset();
      resolve();
    })
      .then(() => {
        return new Promise(async resolve => {
          let promises = [];
          promises.push(await this.getTextsOfPage(this.pageIndex, op));
          resolve(promises);
        });
      })
      .then(promises => {
        return Promise.all(promises);
      })
      .then(() => {
        return new Promise(resolve => {
          let err = null;
          if (op !== "tts") {
            if (this.textsToRead.length === 0) {
              err = "ERR_NO_TEXT";
            }
          }
          resolve({ err: err, res: this.textsToRead });
        });
      })
      .catch(err => {
        console.error("Pericles.viewerDoc.getTexts.error", err);
      });
  }

  getTextsOfPage(index, op = "tts") {
    console.log("Pericles.viewerDoc.getTextsOfPage(index, op)", index, op);
    return new Promise(async resolve => {
      this.page = this.pages[index];
      console.log("Pericles.viewerDoc.getTextsOfPage.page", this.page);
      if (this.page) {
        let oldScrollTop = this.viewport.scrollTop;
        this.viewport.scrollTop = this.page.offsetTop;
        await this.processSentencesInParagraphs(this.page, op);
        this.viewport.scrollTop = oldScrollTop;
      }
      resolve();
    }).catch(err => {
      console.error("Pericles.viewerDoc.getTextsOfPage.error", err);
    });
  }

  processSentencesInParagraphs(page, op = "tts") {
    // console.log('Pericles.viewerDoc.processSentencesInParagraphs(page, op)', page, op);
    return Promise.resolve()
      .then(async () => {
        const paragraphs = page.querySelectorAll(this.paraIdent);
        let processedHtmlText,
          sentences,
          nextParagraph,
          elemConcated,
          preSentences,
          sentenceIndexIncr;
        processedHtmlText = "";
        // elemConcated = [];
        sentenceIndexIncr = false;
        // await asyncForEach(paragraphs, async (paragraph) => {
        //     pHtmlText = processHtmlText($(paragraph).text()).trim();
        //     processedHtmlText+= pHtmlText;
        //     nextParagraph = paragraph.nextSibling;
        //     preSentences = (nlp(pHtmlText).sentences().data()).map(s => s.text.trim());
        //     sentences = (nlp(processedHtmlText).sentences().data()).map(s => s.text.trim());
        //     // elemConcated.push(paragraph);
        //     // console.log('nextParagraph', nextParagraph, 'nextOffset', nextParagraph.offsetTop, '; paragraph', paragraph, ' offset', paragraph.offsetTop);
        //     if (!nextParagraph) {
        //         this.addSentencesToTextToRead(sentences);
        //         processedHtmlText = '';
        //         await this.setSentences(paragraph.parentNode, sentences, true);
        //     } else if (
        //         nextParagraph.offsetTop >= (paragraph.offsetTop + paragraph.offsetHeight + (paragraph.offsetHeight * 0.25)) ||
        //         paragraph.offsetTop >= (nextParagraph.offsetTop + nextParagraph.offsetHeight + (nextParagraph.offsetHeight * 0.25))
        //     ) {
        //         this.addSentencesToTextToRead(sentences);
        //         processedHtmlText = '';
        //         await this.setSentences(paragraph.parentNode, sentences, true);
        //     }else{
        //         await this.setSentences(paragraph, [pHtmlText], false);
        //     }
        // })

        await asyncForEach(paragraphs, async paragraph => {
          processedHtmlText = processHtmlText(paragraph.textContent).trim();
          console.log("processedHtmlText", processedHtmlText);
          sentences = nlp(processedHtmlText)
            .sentences()
            .data()
            .map(s => s.text.trim());
          // console.log(processedHtmlText, sentences, paragraph);
          await this.setSentences(paragraph, sentences);
          console.log("sentences", sentences);
          this.addSentencesToTextToRead(sentences);
        });
      })
      .catch(err => {
        console.error(
          "Pericles.viewerDoc.processSentencesInParagraphs.error",
          err
        );
      });
  }

  addSentencesToTextToRead(sentences) {
    // console.log('Pericles.viewerDoc.addSentencesToTextToRead(sentences)', sentences);
    for (let i = 0; i < sentences.length; i++) {
      if (sentences[i]) {
        this.textsToRead.push({ text: sentences[i] });
      }
    }
  }

  async setSentences(pElem, sentences, sentenceIndexIncr) {
    // console.log('Pericles.viewerDoc.setSentences(pElem, sentences)', pElem, sentences);
    if (typeof sentenceIndexIncr === "undefined") sentenceIndexIncr = true;

    let copiedSentences = createDeepCopy(sentences);
    let walk = document.createTreeWalker(
      pElem,
      NodeFilter.SHOW_TEXT,
      null,
      false
    );
    let sentenceIndexInParagraph = 0;
    let copyOfSentenceIndex = this.sentenceIndex;
    let n, id;

    while ((n = walk.nextNode())) {
      try {
        sentenceIndexInParagraph = await this.setSentencesHelper(
          n,
          copiedSentences,
          sentenceIndexInParagraph,
          sentenceIndexIncr
        );
      } catch (e) {
        console.error("setSentencesHelper", e);
      }
    }
    for (let i = 0; i < sentences.length; i++) {
      id = identPrefix + copyOfSentenceIndex;
      let sentenceNodes = pElem.getElementsByClassName(id);
      await this.setWords(sentenceNodes, sentences[i], copyOfSentenceIndex);
      copyOfSentenceIndex++;
    }
  }

  async setWords(sentenceElems, sentence, senIndex) {
    // console.log('Pericles.viewerDoc.setWords(sentenceElems, sentence, senIndex)', sentenceElems, sentence, senIndex);
    try {
      let wordIndex = 0;
      let ttsWords = sentence.split(" ");
      for (let i = 0; i < sentenceElems.length; i++) {
        let nrSentence = $(sentenceElems[i]);
        let words = $(nrSentence)
          .text()
          .split(" ");
        $(nrSentence).empty();
        $.each(words, (i, v) => {
          let word = processHtmlText(v).trim();
          if (word) {
            let currTtsWord = ttsWords[wordIndex];
            // if (!currTtsWord
            // return;
            if (currTtsWord && currTtsWord.indexOf(word) === 0) {
              let nrWord = document.createElement(wordTag);
              $(nrWord).addClass(identPrefix + senIndex + "w" + wordIndex);
              $(nrWord).text(word);
              $(nrSentence).append(nrWord);
              ttsWords[wordIndex] = ttsWords[wordIndex].substring(word.length);
              if (!ttsWords[wordIndex]) {
                wordIndex++;
              }
            } else {
              $(nrSentence).append(document.createTextNode(word));
            }
          }
          if (i < words.length - 1) {
            $(nrSentence).append(document.createTextNode(" "));
          }
        });
      }
    } catch (err) {
      console.error("Pericles.viewerDoc.setWords.error", err);
    }
  }

  async setSentencesHelper(
    n,
    sentences,
    sentenceIndexInParagraph,
    sentenceIndexIncr
  ) {
    // console.log('Pericles.viewerDoc.setSentencesHelper(n, sentences, sentenceIndexInParagraph)', n, sentences, sentenceIndexInParagraph);
    let nrSentence = document.createElement(senTag);
    $(nrSentence).addClass(identPrefix + this.sentenceIndex);
    if (!sentences[sentenceIndexInParagraph]) {
      return sentenceIndexInParagraph;
    }
    let ttsSentence = sentences[sentenceIndexInParagraph].trim();
    let nodeText = processHtmlText($(n).text()).trim();
    if (!nodeText) {
      return sentenceIndexInParagraph;
    }
    if (nodeText.length > ttsSentence.length) {
      let splitIndex = await this.findIndexOfSentence(n, ttsSentence);
      let remainder = n.splitText(splitIndex);
      $(n).wrap(nrSentence);
      sentences[sentenceIndexInParagraph] = ttsSentence.substring(
        processHtmlText($(n).text()).trim().length
      );
      if (sentenceIndexIncr) {
        sentenceIndexInParagraph++;
        this.sentenceIndex++;
      }
    } else {
      if (ttsSentence.indexOf(nodeText) === 0) {
        $(n).wrap(nrSentence);
        sentences[sentenceIndexInParagraph] = ttsSentence
          .substring(nodeText.length)
          .trim();
        if (!sentences[sentenceIndexInParagraph]) {
          if (sentenceIndexIncr) {
            sentenceIndexInParagraph++;
            this.sentenceIndex++;
          }
        }
      }
    }
    return sentenceIndexInParagraph;
  }

  findIndexOfSentence(textNode, sentence) {
    // console.log('Pericles.viewerDoc.findIndexOfSentence(textNode, sentence)');
    return new Promise(resolve => {
      let numTtsWords = sentence.split(" ").length;
      let nodeWords = $(textNode)
        .text()
        .split(" ");
      let nodeWordsIndex = 0;
      let resultIndex = 0;
      while (numTtsWords > 0 && nodeWordsIndex < nodeWords.length) {
        resultIndex++;
        while (
          !nodeWords[nodeWordsIndex] ||
          !nodeWords[nodeWordsIndex].trim()
        ) {
          nodeWordsIndex++;
          resultIndex++;
        }
        resultIndex += nodeWords[nodeWordsIndex].length;
        nodeWordsIndex++;
        numTtsWords--;
      }
      resolve(resultIndex);
    }).catch(err => {
      console.error("Pericles.viewerDoc.findIndexOfSentence.error", err);
    });
  }
}
