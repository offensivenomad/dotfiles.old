import "./content.css";
import $ from "jquery";
import htmlparser from "./html-parser/html-parser.core";
import store from "../src/store/store";
import { PARSER, PLAYER, CONTENT } from "../src/core/types";
import { mpToBackground } from "../src/lib/mp/mp";

import {
  highlightSentence,
  unHighlightSentence,
  scrollToSection,
  scrollToAdjacentPage
} from "./speech/speech.ui";

// init
/*eslint-disable */
const core = chrome || browser;
/*eslint-enable */

const fns = {};
const webParser = htmlparser.getParserByUrl();
const specialSite = htmlparser.specialSite(window.location.host);
if (specialSite && specialSite.junk) {
  const block = htmlparser.specialSiteGetBlock(specialSite);
  if (block && webParser.setBlock) webParser.setBlock(block);
  console.log("is special site", "block", specialSite, block);
  // const ignoreTags = htmlparser.specialSiteTagsToQuery(specialSite.junk);
  // webParser.ignoreTags += ignoreTags;
  // console.log("ignoreTags", webParser.ignoreTags);
}

$(document).on("click", "ps-sen", async function() {
  const key = Number(
    $(this)
      .attr("class")
      .match(/s([0-9]+)/)[1]
  );
  console.log("Pericles.content.ps-sen.clicked(key)", key);
  store.dispatch({
    type: PLAYER.EPIC.HALT
  });

  store.dispatch({
    type: PLAYER.ACTION.UPDATE,
    status: PLAYER.STATUS.IS_READY,
    currentSection: key
  });

  store.dispatch({
    type: CONTENT.ACTION.SKIP_ANIMATE,
    value: true
  });

  setTimeout(() => {
    store.dispatch({
      type: PLAYER.EPIC.PLAY
    });
  }, 100);
});

// methdods
fns.getSections = async () => {
  console.log("fns.getSections");
  const block = htmlparser.specialSiteGetBlock(specialSite);
  if (block && webParser.setBlock) webParser.setBlock(block);
  core.runtime.sendMessage({
    type: "event",
    data: "visited",
    action: window.location.host,
    url: window.location.href
  });

  const getTextsFailed = () => {
    console.log("getTextsFailed");
    store.dispatch({
      type: PLAYER.ACTION.UPDATE,
      status: PLAYER.STATUS.IS_ERROR
    });
  };
  let texts = false;
  try {
    texts = await webParser.getTexts();
  } catch (e) {
    getTextsFailed();
    throw new Error("Could not retrive sections");
  }

  if (!texts || texts.err || !texts.res) {
    getTextsFailed();
    throw new Error("Could not retrive sections");
  }
  console.log("Pericles.content.getSections", texts);

  const sections = [];
  texts.res.forEach(res => {
    if (res) sections.push(res);
  });

  store.dispatch({
    type: PARSER.ACTION.SET_SECTIONS,
    value: sections
  });
  store.dispatch({
    type: PLAYER.EPIC.PLAY
  });
  fns.highlightSentence(0);
  fns.scrollToSection(0);

  console.log("getText Success");

  return true;
};

fns.reset = async () => {
  console.log("Pericles.content.reset()");
  try {
    await webParser.reset();
  } catch (e) {
    throw new Error("could not reset webParser");
  }

  return true;
};

fns.highlightColor = async val => {
  const state = store.getState();
  if (!val) val = "#" + (state.highlightColor || "fffc02");
  val += "40";

  console.log("Pericles.content.highlightColor", val, state);
  document.documentElement.style.setProperty("--pulse-color", val);
};

fns.highlightSentence = async key => {
  console.log("Pericles.content.highlightSentence", key);
  return highlightSentence(key);
};

fns.webParserType = async () => {
  console.log("Pericles.content.webParserType");
  return webParser.type;
};

fns.scrollToAdjacentPage = async () => {
  const out = await scrollToAdjacentPage(
    webParser.nextPage,
    webParser.viewport
  );
  console.log("Pericles.content.scrollToAdjacentPage", out);
  return out;
};

fns.unHighlightSentence = async key => {
  return unHighlightSentence(key);
};

fns.scrollToSection = async key => {
  console.log("Pericles.content.scrollToSection", webParser);
  const state = store.getState();
  if (state.autoscroll !== true) {
    console.log("autoscroll is off");
    return true;
  }

  if (webParser.type === "viewerDoc")
    await scrollToSection(key, webParser.viewport, webParser.page);
  else if (webParser.type === "googleDoc")
    await scrollToSection(key, webParser.viewport);
  else await scrollToSection(key);
  return true;
};

(async () => {
  await fns.highlightColor();
})();

window.addEventListener("beforeunload", async () => {
  await mpToBackground("tabClosed");
});

const contentState = {
  currentSection: 0,
  status: 0
};

store.subscribe(async () => {
  const state = store.getState();
  console.log("state", state);
  if (
    state.player.currentSection !== contentState.currentSection &&
    state.player.status === PLAYER.STATUS.IS_PLAYING
  ) {
    contentState.currentSection = state.player.currentSection;
    fns.highlightSentence(state.player.currentSection);
    if (!state.skipAnimate) {
      fns.scrollToSection(state.player.currentSection);
    } else {
      store.dispatch({
        type: CONTENT.ACTION.SKIP_ANIMATE,
        value: false
      });
    }
  }

  if (
    contentState.status !== state.player.status &&
    state.player.status === PLAYER.STATUS.IS_STOPPED
  ) {
    console.log("player was stopped, reset web parser");
    await fns.reset();
  }
  contentState.status = state.player.status;
});

core.runtime.onMessage.addListener(async (request, sender, sendResponse) => {
  console.log("Pericles.content.onMessage", request);
  try {
    const fn = fns[request.message];
    const out = await fn.call(null, request.params);
    console.log(
      "Pericles.content.onMessage(message, out)",
      request.message,
      out,
      sender
    );
    sendResponse(out);
  } catch (e) {
    console.error("Pericles.content.onMessage", e);
    sendResponse("error");
  }
});

const hotkeyEvents = {
  play: () => {
    store.dispatch({
      type: PLAYER.EPIC.PLAY
    });
  },
  stop: () => {
    store.dispatch({
      type: PLAYER.EPIC.STOP
    });
  },
  next: () => {
    store.dispatch({
      type: PLAYER.EPIC.NEXT
    });
  },
  prev: () => {
    store.dispatch({
      type: PLAYER.EPIC.PREV
    });
  }
};

let t;
const registerKeyUpListener = () => {
  document.addEventListener("keyup", e => {
    clearTimeout(t);
    t = setTimeout(() => {
      const state = store.getState();
      const find = Object.keys(state.hotkeys).find(key => {
        return state.hotkeys[key][0].which === e.which;
      });
      if (
        !state.disableHotkeys &&
        state.player.status !== PLAYER.STATUS.IS_STOPPED &&
        find &&
        hotkeyEvents[find]
      )
        hotkeyEvents[find]();
    }, 150);
  });
};

registerKeyUpListener();
