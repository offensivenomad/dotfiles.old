import $ from "jquery";

export const asyncForEach = async (array, callback) => {
  for (let index = 0; index < array.length; index++) {
    await callback(array[index], index, array);
  }
};

function paragraphSplitter() {
  return /(?:\s*\r?\n\s*){2,}/;
}

export function getInnerText(elem) {
  var text = elem.innerText;
  return text ? text.trim() : "";
}

export function isNotEmpty(text) {
  return text;
}

export function fixParagraphs(texts) {
  var out = [];
  var para = "";
  for (var i = 0; i < texts.length; i++) {
    if (!texts[i]) {
      if (para) {
        out.push(para);
        para = "";
      }
      continue;
    }
    if (para) {
      if (/-$/.test(para)) para = para.substr(0, para.length - 1);
      else para += " ";
    }
    para += texts[i].replace(/-\r?\n/g, "");
    if (texts[i].match(/[.!?:)"'\u2019\u201d]$/)) {
      out.push(para);
      para = "";
    }
  }
  if (para) out.push(para);
  return out;
}

export function tryGetTexts(getTexts, millis) {
  // console.log('Pericles.htmlparser.common.tryGetTexts(getTexts, millis)', getTexts, millis);
  return waitMillis(500)
    .then(getTexts)
    .then(function(texts) {
      if (texts && !texts.length && millis - 500 > 0)
        return tryGetTexts(getTexts, millis - 500);
      else return texts;
    });
}

function waitMillis(millis) {
  return new Promise(function(fulfill) {
    setTimeout(fulfill, millis);
  });
}

function loadPageScript(url) {
  if (!$("head").length) $("<head>").prependTo("html");
  $.ajax({
    dataType: "script",
    cache: true,
    url: url
  });
}

function simulateMouseEvent(element, eventName, coordX, coordY) {
  element.dispatchEvent(
    new MouseEvent(eventName, {
      view: window,
      bubbles: true,
      cancelable: true,
      clientX: coordX,
      clientY: coordY,
      button: 0
    })
  );
}

function simulateClick(elementToClick) {
  var box = elementToClick.getBoundingClientRect(),
    coordX = box.left + (box.right - box.left) / 2,
    coordY = box.top + (box.bottom - box.top) / 2;
  simulateMouseEvent(elementToClick, "mousedown", coordX, coordY);
  simulateMouseEvent(elementToClick, "mouseup", coordX, coordY);
  simulateMouseEvent(elementToClick, "click", coordX, coordY);
}

export function processHtmlText(text) {
  // console.log("processHtmlText", text);
  text = removeLineBreaks(text);
  text = replaceHTMLSpaces(text);
  text = removeExtraSpaces(text);
  // console.log("processHtmlText.return", text);
  return text;
}

function removeLineBreaks(text) {
  return text.replace(/(\r\n|\n|\r)/gm, "");
}

function replaceHTMLSpaces(text) {
  text = text.replace(/&nbsp;/gi, " ");
  text = text.replace(/[\u200c|\u200b|\u200d|\ufeff]/gi, " ");
  return text;
}

function removeHTMLSpaces(text) {
  text = text.trim();
  text = text.replace(/[&nbsp;|\s]+/gi, "");
  text = text.replace(/[\u200c|\u200b|\u200d|\ufeff]+/gi, "");
  return text;
}

function removeExtraSpaces(text) {
  return text.replace(/\s{2,}/g, " ").trim();
}

export const getDocPageIndex = (pages, viewport) => {
  const index = pages.findIndex(page => {
    return page.offsetTop + page.offsetHeight / 2 > viewport.scrollTop;
  });
  return index === -1 ? pages.length - 1 : index;
};

export const createDeepCopy = array => {
  // console.log('Pericles.htmlparser.common.createDeepCopy(array)', array);
  let deepCopy = [];
  for (let i = 0; i < array.length; i++) {
    deepCopy.push(array[i]);
  }
  return deepCopy;
};

export const removePSTags = async () => {
  // console.log('Pericles.htmlparser.common.removePSTags()');
  try {
    await replacePSTagsWithTextNodes(senTag);
  } catch (err) {
    console.error("Pericles.htmlparser.common.removePSTags.error", err);
  }
};

export const replacePSTagsWithTextNodes = async tagName => {
  // console.log('Pericles.htmlparser.common.replacePSTagsWithTextNodes(tagName)', tagName);

  return new Promise(async resolve => {
    let nodes = $(document.body)
      .find(tagName)
      .get();
    for (let i = 0; i < nodes.length; i++) {
      await replacePSTagWithTextNode(nodes[i]);
    }
    resolve();
  });
};

export const setSentencesHelper = (node, sentence, index, sentenceIndex) => {
  console.log(
    "setSentencesHelper - node, sentence, index, sentenceIndex, isEmpty",
    node,
    sentence,
    index,
    sentenceIndex,
    !!!removeHTMLSpaces(node.textContent).length
  );
  if (!removeHTMLSpaces(node.textContent).length)
    return { index, senText: sentence, sentenceIndex };

  const psSentence = window.document.createElement(senTag);
  $(psSentence).addClass(identPrefix + sentenceIndex);
  let nodeText = processHtmlText(node.textContent).trim();
  // const nodeText = node.textContent;
  let senText = (sentence || "").trim();
  console.log(
    "setSentencesHelper - senText, senText.length",
    senText,
    senText.length
  );

  if (senText.length !== 0 && nodeText.length > senText.length) {
    let sliceIndex = senText.length;
    const words = senText.split(" ");
    // console.log("setSentencesHelper - words", words);
    const lastWord = words[words.length - 1];
    const lastWordIndex = senText.indexOf(lastWord);
    // console.log("setSentencesHelper - lastWord", lastWord);
    // console.log("setSentencesHelper - lastWordIndex", lastWordIndex);
    // we are cutting in word
    // console.log("setSentencesHelper - sliceIndex", sliceIndex);
    if (
      sliceIndex > lastWordIndex &&
      sliceIndex < lastWordIndex + lastWord.length
    ) {
      const correctIndex = senText.indexOf(lastWord) + lastWord.length;
      // console.log("setSentencesHelper - correctIndex", correctIndex);
      if (correctIndex !== sliceIndex) {
        sliceIndex = correctIndex;
      }
    }
    node.splitText(sliceIndex);
  }
  nodeText = processHtmlText(node.textContent).trim();
  // nodeText = node.textContent;
  console.log(
    "setSentencesHelper - nodeText, nodeText.length",
    nodeText,
    nodeText.length
  );
  senText = senText.slice(nodeText.length);
  // if (senText.length <= 1) senText = "";

  console.log("setSentencesHelper - senText.sliced", senText, senText.length);
  if (senText.length === 0) {
    index++;
    sentenceIndex++;
  }
  // console.log("setSentencesHelper - wrapping node", node, psSentence);
  node.parentNode.insertBefore(psSentence, node);
  psSentence.appendChild(node);

  return { index, senText, sentenceIndex };
};

export const replacePSTagWithTextNode = async node => {
  // console.log('Pericles.htmlparser.common.replacePSTagWithTextNode(node)', node);

  return new Promise(resolve => {
    let text = $(node).text();
    $(node).replaceWith(document.createTextNode(text));
    resolve();
  }).catch(err => {
    console.error("Pericles.googleDoc.replaceNRTagWithTextNode.err", err);
  });
};

export const senTag = "ps-sen";
export const wordTag = "ps-wor";
export const paraTag = "ps-par";
export const identPrefix = "s";
