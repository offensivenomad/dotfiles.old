import $ from "jquery";

const doc = function() {
  let textsToRead = [];
  let sentenceIndex = 0;
  let viewport = $(".drive-viewer-paginated-scrollable").get(0);
  let pages = $(".drive-viewer-paginated-page");

  this.reset = async () => {
    await reset();
    this.container = false;
  };

  this.getCurrentIndex = function() {
    console.log("Pericles.googleDrive.getCurrentIndex()");
    for (let i = 0; i < pages.length; i++)
      if (
        pages.eq(i).position().top >
        viewport.scrollTop + $(viewport).height() / 2
      )
        break;
    return i - 1;
  };

  this.getTexts = function() {
    console.log("Pericles.googleDrive.getTexts()");
    return new Promise(async resolve => {
      await reset();
      resolve();
    })
      .then(() => {
        return new Promise(resolve => {
          let promises = [];
          for (let i = 0; i < pages.length; i++) {
            promises.push(getTextsOfPage(i));
          }
          resolve(promises);
        });
      })
      .then(promises => {
        return Promise.all(promises);
      })
      .then(() => {
        return new Promise(resolve => {
          let err = null;
          if (textsToRead.length === 0) {
            err = "ERR_NO_TEXT";
          }
          resolve({
            err: err,
            res: textsToRead
          });
        });
      })
      .catch(err => {
        console.error("Pericles.googleDrive.getTexts()", err);
      });
  };

  function getTextsOfPage(index) {
    console.log("Pericles.googleDrive.getTextsOfPage(index)", index);
    return new Promise(resolve => {
      let page = pages.get(index);
      if (page) {
        let oldScrollTop = viewport.scrollTop;
        viewport.scrollTop = $(page).position().top;
        return tryGetTexts(getTexts.bind(page), 3000).then(result => {
          viewport.scrollTop = oldScrollTop;
          for (let j = 0; j < result.length; j++) {
            textsToRead[sentenceIndex] = {};
            textsToRead[sentenceIndex]["text"] = result[j];
            sentenceIndex++;
          }
          resolve(result);
        });
      } else {
        resolve([]);
      }
    }).catch(err => {
      console.error("Pericles.googleDrive.getTextsOfPage()", err);
    });
  }

  function reset() {
    console.log("Pericles.googleDrive.reset()");
    return Promise.resolve()
      .then(() => {
        textsToRead = [];
        sentenceIndex = 0;
      })
      .catch(err => {
        console.error("Pericles.googleDrive.reset()", err);
      });
  }

  function getTexts() {
    console.log("Pericles.googleDrive.getTexts()");
    let texts = $("p", this)
      .get()
      .map(getInnerText)
      .filter(isNotEmpty);
    return fixParagraphs(texts);
  }
};

export default doc;
