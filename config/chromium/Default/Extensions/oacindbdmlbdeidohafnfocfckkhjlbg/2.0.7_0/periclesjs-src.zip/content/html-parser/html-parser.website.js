import $ from "jquery";
import nlp from "compromise";
import HTMLBaseParser from "./html-base-parser";
import {
  processHtmlText,
  getInnerText,
  setSentencesHelper
} from "./html-parser.common.js";

const senTag = "ps-sen";
const wordTag = "ps-wor";
const paraTag = "ps-par";
const identPrefix = "s";
const paragraphSplitter = /(?:\s*\r?\n\s*){2,}/;

let id;

export default class WebsiteParser extends HTMLBaseParser {
  constructor() {
    super();

    this.type = "htmlDoc";
    this.ignoreTags =
      "sup, select, textarea, button, label, audio, video, dialog, embed, menu, nav, noframes, noscript, object, script, style, svg, aside, footer, #footer, .no-read-aloud ";
    this.container = null;
    this.document = null;
  }

  setBlock(container) {
    this.container = container;
  }

  async getTexts(op = "tts") {
    return new Promise(async resolve => {
      await this.reset();
      resolve();
    })
      .then(() => {
        return new Promise(async resolve => {
          let texts = [];
          texts = await this.parse(op);
          let err = null;
          if (texts.length === 0) {
            err = "ERR_NO_TEXT";
          }
          resolve({
            err: err,
            res: texts
          });
        });
      })
      .catch(err => {
        console.error("Pericles.webParser.getTexts.err", err);
      });
  }

  async parse(op = "tts") {
    // console.log('parsing')
    return new Promise(resolve => {
      // let start = new Date();
      let textBlocks = this.findTextBlocks(100);
      // console.log('textBlocks', textBlocks);
      let countChars = textBlocks.reduce((sum, elem) => {
        return sum + getInnerText(elem).length;
      }, 0);
      // console.log("parse.countChars", countChars);
      if (countChars < 1000) {
        textBlocks = this.findTextBlocks(3);
        let texts = textBlocks.map(getInnerText);
        let head, tail;
        for (let i = 3; i < texts.length && !head; i++) {
          let dist = this.getGaussian(texts, 0, i);
          if (texts[i].length > dist.mean + 2 * dist.stdev) head = i;
        }
        for (let i = texts.length - 4; i >= 0 && !tail; i--) {
          let dist = this.getGaussian(texts, i + 1, texts.length);
          if (texts[i].length > dist.mean + 2 * dist.stdev) tail = i + 1;
        }
        if (head || tail) {
          textBlocks = textBlocks.slice(head || 0, tail);
        }
      }
      let toRead = [];
      for (let i = 0; i < textBlocks.length; i++) {
        toRead.push.apply(
          toRead,
          this.findHeadingsFor(textBlocks[i], textBlocks[i - 1])
        );
        toRead.push(textBlocks[i]);
      }
      resolve(toRead);
    })
      .then(toRead => {
        // console.log("toRead", toRead);
        return new Promise(async resolve => {
          if (op === "tts") {
            for (let i = 0; i < toRead.length; i++) {
              await this.getTexts2(toRead[i]);
            }
          }
          resolve(this.textsToRead);
        });
      })
      .catch(err => {
        console.error("Pericles.webParser.parse.err", err);
      });
  }

  findTextBlocks(threshold) {
    let skipTags = "h1, h2, h3, h4, h5, h6, p, a[href], " + this.ignoreTags;
    let isTextNode = node => {
      return node.nodeType === 3 && node.nodeValue.trim().length >= 3;
    };
    let isParagraph = node => {
      return (
        node.nodeType === 1 &&
        $(node).is("p:visible") &&
        getInnerText(node).length >= threshold
      );
    };
    let hasTextNodes = elem => {
      return (
        this.someChildNodes(elem, isTextNode) &&
        getInnerText(elem).length >= threshold
      );
    };
    let hasParagraphs = elem => {
      return this.someChildNodes(elem, isParagraph);
    };
    let containsTextBlocks = elem => {
      let childElems = $(elem)
        .children(":not(" + skipTags + ")")
        .get();
      return (
        childElems.some(hasTextNodes) ||
        childElems.some(hasParagraphs) ||
        childElems.some(containsTextBlocks)
      );
    };
    let addBlock = (elem, multi) => {
      if (multi) $(elem).data("read-aloud-multi-block", true);
      textBlocks.push(elem);
    };
    const walk = function() {
      // console.log('walk', this);
      if (
        $(this).is("frame, iframe") &&
        this.contentDocument &&
        this.contentDocument.body
      )
        try {
          walk.call(this.contentDocument.body);
        } catch (err) {
          console.error("Pericles.webParser.walk.call().err", err);
        }
      else if ($(this).is("dl")) addBlock(this);
      else if ($(this).is("ol, ul")) {
        let items = $(this)
          .children()
          .get();
        if (items.some(hasTextNodes)) addBlock(this);
        else if (items.some(hasParagraphs)) addBlock(this, true);
        else if (items.some(containsTextBlocks)) addBlock(this, true);
      } else if ($(this).is("tbody")) {
        let rows = $(this).children();
        if (rows.length > 3 || rows.eq(0).children().length > 3) {
          if (rows.get().some(containsTextBlocks)) addBlock(this, true);
        } else rows.each(walk);
      } else {
        if (hasTextNodes(this)) addBlock(this);
        else if (hasParagraphs(this)) addBlock(this, true);
        else
          $(this)
            .children(":not(" + skipTags + ")")
            .each(walk);
      }
    };
    let textBlocks = [];

    walk.call(this.container || document.body);

    // only return visible objects
    return textBlocks.filter(elem => {
      return $(elem).is(":visible") && $(elem).offset().left >= 0;
    });
  }

  getGaussian(texts, start, end) {
    // console.log("start", start);
    // console.log("end", end);
    // if (start == undefined) start = 0;
    // if (end == undefined) end = texts.length;
    let sum = 0;
    for (let i = start; i < end; i++) sum += texts[i].length;
    let mean = sum / (end - start);
    let letiance = 0;
    for (let i = start; i < end; i++)
      letiance += (texts[i].length - mean) * (texts[i].length - mean);
    return {
      mean: mean,
      stdev: Math.sqrt(letiance)
    };
  }

  async getTexts2(elem) {
    // console.log('getting texts 2');
    return new Promise(async resolve => {
      let toHide = $(elem)
        .find(":visible")
        .filter(this.dontRead)
        .hide();
      if ($(elem).data("read-aloud-multi-block")) {
        let children = $(elem)
          .children(":visible")
          .get();
        for (let i = 0; i < children.length; i++) {
          await this.traverseDOM(children[i]);
        }
      } else {
        await this.traverseDOM(elem);
      }
      $(elem)
        .find(".read-aloud-numbering")
        .remove();
      toHide.show();
      resolve();
    }).catch(err => {
      console.error("Pericles.webParser.getTexts.err", err);
    });
  }

  skipNode(node) {
    const skip = ["figure"];
    return !node.tagName || skip.includes(node.tagName.toLocaleLowerCase());
  }

  async traverseDOM(node) {
    const children = $(node).contents();
    try {
      console.log("traverseDOM.node", node);
      // console.log("traverseDOM.children", children);
      if (
        node.nodeType !== 3 &&
        (this.skipNode(node) ||
          $(node).css("display") === "none" ||
          $(node).css("visibility") === "hidden")
      ) {
        return;
      }
      if (children.length === 0) {
        if (node.nodeType === 3 && node.nodeValue.trim()) {
          let sentences = nlp(processHtmlText(node.nodeValue))
            .sentences()
            .data();
          // console.log('Pericles.webParser.traverseDOM.sentences', sentences);
          if (sentences.length > 0) {
            if (sentences.length > 1) {
              console.log("traverseDOM.sentences - node", node);
              let p = this.setParagraph(node);
              console.log("traverseDOM.sentences - p", p);
              for (let i = 0; i < sentences.length; i++) {
                console.log("traverseDOM.sentences - sentence", sentences[i]);
                let s = this.setSentenceInParagraph(sentences[i].text + " ");
                p.appendChild(s);
                this.visitNode(s);
                this.sentenceIndex++;
              }
            } else {
              let s = this.setSentence(node);
              this.visitNode(s);
              this.sentenceIndex++;
            }
          }
          return;
        } else {
          return;
        }
      } else {
        if ($(node).get(0).nodeName === "P") {
          await this.processSentencesInParagraphs(node);
        } else {
          for (let i = 0; i < children.length; i++) {
            await this.traverseDOM(children[i]);
          }
        }
      }
    } catch (err) {
      console.error("Pericles.webParser.traverseDOM(node)->err", err);
      return;
    }
  }

  async processSentencesInParagraphs(p) {
    // console.log("processSentencesInParagraphs", p);
    return Promise.resolve()
      .then(async () => {
        let preProcessed = $(p)
          .clone()
          .children("sup")
          .detach()
          .end()
          .text();
        // console.log(
        // "processSentencesInParagraphs - preProcessed",
        // preProcessed
        // );
        // let preProcessed = $(p).text();
        let processedHtmlText = processHtmlText(preProcessed).trim();
        if (!processedHtmlText.length) return;
        let sentences = nlp(processedHtmlText)
          .sentences()
          .data()
          .map(s => s.text.trim());
        // console.log("processSentencesInParagraphs.sentences", sentences, p);
        try {
          await this.setSentences(p, sentences, this.sentenceIndex);
        } catch (e) {
          console.error(e);
        }
        this.addSentencesToTextToRead(sentences);
      })
      .catch(err => {
        console.error(
          "Pericles.webParser.processSentencesInParagraphs.err",
          err
        );
      });
  }

  addSentencesToTextToRead(sentences) {
    // console.log("addSentencesToTextToRead", sentences);
    for (let i = 0; i < sentences.length; i++) {
      this.textsToRead.push({
        text: sentences[i]
      });
    }
  }

  async setSentences(pElem, sentences) {
    let copiedSentences = this.createDeepCopy(sentences);
    let walk = document.createTreeWalker(
      pElem,
      NodeFilter.SHOW_TEXT,
      null,
      false
    );
    let sentenceIndexInParagraph = 0;
    let copyOfSentenceIndex = this.sentenceIndex;
    let textNode;
    while ((textNode = walk.nextNode())) {
      if (
        ![
          textNode.parentNode.tagName,
          textNode.parentNode.parentNode.tagName
        ].includes("SUP")
      ) {
        try {
          // console.log("setSentencesHelper - sentences", [...copiedSentences]);
          const output = setSentencesHelper(
            textNode,
            copiedSentences[sentenceIndexInParagraph],
            sentenceIndexInParagraph,
            this.sentenceIndex
          );
          copiedSentences[sentenceIndexInParagraph] = output.senText;
          sentenceIndexInParagraph = output.index;
          this.sentenceIndex = output.sentenceIndex;
          // const output = await this.setSentencesHelper(
          // textNode,
          // copiedSentences,
          // sentenceIndexInParagraph
          // );
          // sentenceIndexInParagraph = output;
          // console.log("setSentencesHelper-response", output);
        } catch (e) {
          console.error("setSentences", e);
        }
      }
    }
    // console.log("finished with sentenceHelper");
    // for (let i = 0; i < sentences.length; i++) {
    // id = identPrefix + copyOfSentenceIndex;
    // let sentenceNodes = pElem.getElementsByClassName(id);
    // try {
    // await this.setWords(sentenceNodes, sentences[i], copyOfSentenceIndex);
    // } catch (e) {
    // console.error(e);
    // }
    // copyOfSentenceIndex++;
    // }
  }

  createDeepCopy(array) {
    let deepCopy = [];
    for (let i = 0; i < array.length; i++) {
      deepCopy.push(array[i]);
    }
    return deepCopy;
  }

  async setSentencesHelper2(n, sentences, index) {
    // console.log("setSentencesHelper - n", n, sentences, index);
    let sentenceIndexInParagraph = index;
    const psSentence = document.createElement(senTag);
    $(psSentence).addClass(identPrefix + this.sentenceIndex);
    if (!sentences[sentenceIndexInParagraph]) return sentenceIndexInParagraph;

    const ttsSentence = sentences[sentenceIndexInParagraph].trim();
    // const nodeText = processHtmlText($(n).text()).trim();
    const nodeText = processHtmlText(n.textContent).trim();
    // console.log("setSentencesHelper - jquery.nodeText", nodeText);
    // console.log("setSentencesHelper - vanilla.nodeText", nodeText2);
    // console.log("setSentencesHelper - ttsSentence", ttsSentence);
    // console.log(
    // "setSentencesHelper - sen",
    // sentences[sentenceIndexInParagraph]
    // );

    if (!nodeText) return sentenceIndexInParagraph;

    // console.log(
    // "setSentencesHelper nodeText.length - ttsSentence.lenght",
    // nodeText.length,
    // ttsSentence.length
    // );
    if (nodeText.length > ttsSentence.length) {
      let splitIndex = await this.findIndexOfSentence(n, ttsSentence);
      // console.log("setSentencesHelper - n.length", n.length, splitIndex);
      let extraSpaces = n.nodeValue.match(/^\s+|\s$/g);
      if (extraSpaces) splitIndex -= extraSpaces.length;
      n.splitText(splitIndex);
      // console.log("setSentencesHelper - n", n);
      $(n).wrap(psSentence);
      sentences[sentenceIndexInParagraph] = ttsSentence.substring(
        processHtmlText($(n).text()).trim().length
      );
      sentenceIndexInParagraph++;
      this.sentenceIndex++;
    } else {
      if (ttsSentence.indexOf(nodeText) === 0) {
        $(n).wrap(psSentence);
        sentences[sentenceIndexInParagraph] = ttsSentence
          .substring(nodeText.length)
          .trim();
        if (!sentences[sentenceIndexInParagraph]) {
          sentenceIndexInParagraph++;
          this.sentenceIndex++;
        }
      }
    }
    return sentenceIndexInParagraph;
  }

  async findIndexOfSentence(textNode, sentence) {
    return new Promise(resolve => {
      let numTtsWords = sentence.split(" ").length;
      let nodeWords = $(textNode)
        .text()
        .split(" ");
      let nodeWordsIndex = 0;
      let resultIndex = 0;
      while (numTtsWords > 0 && nodeWordsIndex < nodeWords.length) {
        resultIndex++;
        while (
          !nodeWords[nodeWordsIndex] ||
          !nodeWords[nodeWordsIndex].trim()
        ) {
          nodeWordsIndex++;
          resultIndex++;
        }
        resultIndex += nodeWords[nodeWordsIndex].length;
        nodeWordsIndex++;
        numTtsWords--;
      }
      resolve(resultIndex);
    }).catch(err => {
      console.error("Pericles.webParser.findIndexOfSentence.err", err);
    });
  }

  /*eslint-disable */
  async setWords(sentenceElems, sentence, senIndex) {
    try {
      let wordIndex = 0;
      let ttsWords = sentence.split(" ");
      let word, currTtsWord, psWord;
      let psSentence, words;
      for (let i = 0; i < sentenceElems.length; i++) {
        psSentence = $(sentenceElems[i]);
        words = $(psSentence)
          .text()
          .split(" ");
        $(psSentence).empty();
        $.each(words, (i, v) => {
          word = processHtmlText(v).trim();
          if (word) {
            currTtsWord = ttsWords[wordIndex];
            if (currTtsWord.indexOf(word) === 0) {
              psWord = document.createElement(wordTag);
              $(psWord).addClass(identPrefix + senIndex + "w" + wordIndex);
              $(psWord).text(word);
              $(psSentence).append(psWord);
              ttsWords[wordIndex] = ttsWords[wordIndex].substring(word.length);
              if (!ttsWords[wordIndex]) {
                wordIndex++;
              }
            } else {
              $(psSentence).append(document.createTextNode(word));
            }
          }
          if (i < words.length - 1) {
            $(psSentence).append(document.createTextNode(" "));
          }
        });
      }
    } catch (err) {
      console.error("Pericles.webParser.setWords.err", err);
    }
  }
  /*eslint-enable */

  setParagraph(node) {
    let psParagraph = document.createElement(paraTag);
    $(node).replaceWith(psParagraph);
    return psParagraph;
  }

  setSentence(node) {
    let psSentence = document.createElement(senTag);
    $(psSentence).addClass(identPrefix + this.sentenceIndex);
    psSentence.appendChild(document.createTextNode(node.nodeValue));
    $(node).replaceWith(psSentence);
    return psSentence;
  }

  setSentenceInParagraph(text) {
    let psSentence = document.createElement(senTag);
    $(psSentence).addClass(identPrefix + this.sentenceIndex);
    psSentence.appendChild(document.createTextNode(text));
    return psSentence;
  }

  visitNode(node, wordIndex = 0) {
    let text = $(node)
      .first()
      .text();
    if (text.trim()) {
      this.setHtmlForHighlight($(node).first(), wordIndex);
    }
  }

  setHtmlForHighlight(node, wordIndex) {
    const text = processHtmlText($(node).text());
    if (text && text.length) {
      this.textsToRead[this.sentenceIndex] = {};
      this.textsToRead[this.sentenceIndex]["text"] = text;
    }

    // TODO:: refactor - another setWords() duplicated
    // let words = $(node)
    // .text()
    // .split(" ");
    // $(node).empty();
    // $.each(words, (i, v) => {
    // if (v.trim()) {
    // let psWord = document.createElement(wordTag);
    // $(psWord).addClass(identPrefix + this.sentenceIndex + "w" + wordIndex);
    // $(psWord).text(v);
    // $(node).append(psWord);
    // wordIndex++;
    // }
    // if (i < words.length - 1) {
    // $(node).append(document.createTextNode(" "));
    // }
    // });
    //
  }

  addNumbering() {
    let children = $(this).children();
    let text = children.length ? getInnerText(children.get(0)) : null;
    if (text && !text.match(/^[(]?(\d|[a-zA-Z][).])/))
      children.each(index => {
        $("<span>")
          .addClass("read-aloud-numbering")
          .text(index + 1 + ". ")
          .prependTo(this);
      });
  }

  dontRead() {
    let float = $(this).css("float");
    let position = $(this).css("position");
    return (
      $(this).is(this.ignoreTags) ||
      $(this).is("sup") ||
      float === "right" ||
      position === "fixed"
    );
  }

  getText(elem) {
    return this.addMissingPunctuation(elem.innerText).trim();
  }

  addMissingPunctuation(text) {
    return text.replace(/(\w)(\s*?\r?\n)/g, "$1.$2");
  }

  findHeadingsFor(block, prevBlock) {
    let result = [];
    // if (this.container)
    // return result;

    let firstInnerElem = $(block)
      .find("h1, h2, h3, h4, h5, h6, p")
      .filter(":visible")
      .get(0);
    let currentLevel = this.getHeadingLevel(firstInnerElem);
    let node = this.previousNode(block, true);
    while (node && node !== prevBlock) {
      let ignore = $(node).is(this.ignoreTags);
      if (!ignore && node.nodeType === 1 && $(node).is(":visible")) {
        let level = this.getHeadingLevel(node);
        if (level < currentLevel) {
          result.push(node);
          currentLevel = level;
        }
      }
      node = this.previousNode(node, ignore);
    }
    return result.reverse();
  }

  getHeadingLevel(elem) {
    let matches = elem && /^H(\d)$/i.exec(elem.tagName);
    return matches ? Number(matches[1]) : 100;
  }

  previousNode(node, skipChildren) {
    if ($(node).is("body")) return null;
    if (node.nodeType === 1 && !skipChildren && node.lastChild)
      return node.lastChild;
    if (node.previousSibling) return node.previousSibling;
    return this.previousNode(node.parentNode, true);
  }

  someChildNodes(elem, test) {
    let child = elem.firstChild;
    while (child) {
      if (test(child)) return true;
      child = child.nextSibling;
    }
    return false;
  }

  flatten(array) {
    return [].concat.apply([], array);
  }

  getTextsOnly(elem) {
    var toHide = $(elem)
      .find(":visible")
      .filter(this.dontRead)
      .hide();
    $(elem)
      .find("ol, ul")
      .addBack("ol, ul")
      .each(this.addNumbering);
    var texts = $(elem).data("read-aloud-multi-block")
      ? $(elem)
          .children(":visible")
          .get()
          .map(this.getText)
      : this.getText(elem).split(paragraphSplitter);
    $(elem)
      .find(".read-aloud-numbering")
      .remove();
    toHide.show();
    return texts;
  }
}
