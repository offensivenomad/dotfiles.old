import $ from "jquery";
import { removePSTags, getDocPageIndex } from "./html-parser.common";

export default class AbstractDocParser {
  constructor() {
    this._page = null;
    this.textsToRead = [];
    this.sentenceIndex = 0;
  }

  get pages() {
    return Array.from(document.querySelectorAll(this.pageIdent));
  }

  get pageIndex() {
    return getDocPageIndex(this.pages, this.viewport);
  }

  get page() {
    return this._page;
  }

  get nextPage() {
    return this._page.nextSibling;
  }

  set page(val) {
    this._page = val;
  }

  get viewport() {
    return document.querySelector(this.viewportIdent);
  }

  async reset() {
    // console.log('Pericles.viewerDoc.reset()');
    this.textsToRead = [];
    this.sentenceIndex = 0;
    $(this.viewport).stop();
    await removePSTags();
  }
}
