import $ from "jquery";
import nlp from "compromise";
import {
  tryGetTexts,
  processHtmlText,
  fixParagraphs,
  getInnerText,
  isNotEmpty,
  senTag,
  wordTag,
  paraTag,
  identPrefix
} from "./html-parser.common.js";

const doc = function() {
  this.type = "googleDrivePreview";
  let textsToRead = [];
  let sentenceIndex = 0;
  let viewport, pages;
  let pageIndex = 0;

  this.reset = async () => {
    console.log("Pericles.googleDrivePreview.reset()");
    await reset();
    await removeNRTags();
  };

  this.scrollToAdjacentPage = function(direction) {
    console.log(
      "Pericles.googleDrivePreview.scrollToAdjacentPage(direction)",
      direction
    );
    return new Promise(resolve => {
      let page = null;
      if (direction === "next") {
        if (pageIndex < pages.length - 1 && pageIndex !== -1) {
          page = pages[pageIndex + 1];
        } else {
          resolve("ERR");
        }
      } else {
        if (pageIndex > 0) {
          page = pages[pageIndex - 1];
        } else if (pageIndex === -1) {
          page = pages[pages.length - 2];
        } else {
          resolve("ERR");
        }
      }
      viewport.scrollTop = $(page).position().top;
      resolve();
    }).catch(err => {
      console.error("Pericles.googleDrivePreview.scrollToAdjacentPage", err);
    });
  };

  function getCurrentIndex() {
    console.log("Pericles.googleDrivePreview.getCurrentIndex()");
    let d = $("[role=document]:visible").eq(0);
    viewport = d.parent().get(0);
    pages = d.children().slice(
      d
        .children()
        .first()
        .is("[role=button]")
        ? 2
        : 1
    );
    let index = 0;
    for (let i = 0; i < pages.length; i++) {
      if (
        pages.eq(i).position().top >
        viewport.scrollTop + $(viewport).height() / 2
      ) {
        index = i;
        break;
      }
    }
    return index - 1;
  }

  this.getTexts = function(op = "tts") {
    console.log("Pericles.googleDrivePreview.this.getTexts(op)", op);
    pageIndex = getCurrentIndex();
    return new Promise(async resolve => {
      await reset();
      await removeNRTags();
      resolve();
    })
      .then(() => {
        return new Promise(async resolve => {
          let promises = [];
          promises.push(await getTextsOfPage(pageIndex, op));
          resolve(promises);
        }).catch(err => {
          console.error("Pericles.googleDrivePreview.this.getTexts", err);
        });
      })
      .then(promises => {
        return Promise.all(promises).catch(err => {
          console.error("Pericles.googleDrivePreview.this.getTexts", err);
        });
      })
      .then(() => {
        return new Promise(resolve => {
          let err = null;
          if (op !== "tts") {
            if (textsToRead.length === 0) {
              err = "ERR_NO_TEXT";
            }
          }
          resolve({
            err: err,
            res: textsToRead
          });
        });
      })
      .catch(err => {
        console.error("Pericles.googleDrivePreview.getTexts", err);
      });
  };

  async function removeNRTags() {
    console.log("Pericles.googleDrivePreview.removeNRTags()");
    try {
      await replaceNRTagsWithTextNodes(senTag);
    } catch (err) {
      console.error("Pericles.googleDrivePreview.removeNRTags", err);
    }
  }

  function replaceNRTagsWithTextNodes(tagName) {
    console.log(
      "Pericles.googleDrivePreview.replaceNRTagsWithTextNodes(tagName)",
      tagName
    );
    return new Promise(async resolve => {
      let nodes = $(document.body)
        .find(tagName)
        .get();
      for (let i = 0; i < nodes.length; i++) {
        await replaceNRTagWithTextNode(nodes[i]);
      }
      resolve();
    });
  }

  function replaceNRTagWithTextNode(node) {
    console.log(
      "Pericles.googleDrivePreview.replaceNRTagWithTextNode(node)",
      node
    );
    return new Promise(resolve => {
      let text = $(node).text();
      $(node).replaceWith(document.createTextNode(text));
      resolve();
    }).catch(err => {
      console.error(
        "Pericles.googleDrivePreview.replaceNRTagWithTextNode",
        err
      );
    });
  }

  function reset() {
    console.log("Pericles.googleDrivePreview.reset()");
    return Promise.resolve()
      .then(() => {
        textsToRead = [];
        sentenceIndex = 0;
      })
      .catch(err => {
        console.error("Pericles.googleDrivePreview.reset()", err);
      });
  }

  function getTextsOfPage(index, op = "tts") {
    console.log(
      "Pericles.googleDrivePreview.getTextsOfPage(index, op)",
      index,
      op
    );
    let page = pages.get(index);
    return new Promise(resolve => {
      if (page) {
        let oldScrollTop = viewport.scrollTop;
        viewport.scrollTop = $(page).position().top;
        return tryGetTexts(getTexts.bind(page), 3000).then(result => {
          viewport.scrollTop = oldScrollTop;
          if (op === "tts") {
            let sentences = splitSentences(result);
            addSentencesToTextToRead(sentences);
            resolve(sentences);
          } else {
            addSentencesToTextToRead(result);
            resolve(result);
          }
        });
      } else {
        resolve([]);
      }
    })
      .then(async sentences => {})
      .catch(err => {
        console.error("Pericles.getTextsOfPage", err);
      });
  }

  function splitSentences(sentences) {
    console.log(
      "Pericles.googleDrivePreview.splitSentences(sentences)",
      sentences
    );
    let result = [];
    for (let i = 0; i < sentences.length; i++) {
      let processedHtmlText = sentences[i];
      let splittedSentences = nlp(processedHtmlText)
        .sentences()
        .data()
        .map(s => s.text.trim());
      result = result.concat(splittedSentences);
    }
    return result;
  }

  function processSentencesInParagraphs(page, sentences) {
    console.log(
      "Pericles.googleDrivePreview.processSentencesInParagraphs(page, sentences)",
      page,
      sentences
    );
    return Promise.resolve()
      .then(async () => {
        await setSentences(page, sentences, sentenceIndex);
        addSentencesToTextToRead(sentences);
      })
      .catch(err => {
        console.error(
          "Pericles.googleDrivePreview.processSentencesInParagraphs",
          err
        );
      });
  }
  async function setSentences(pElem, sentences) {
    console.log(
      "Pericles.googleDrivePreview.setSentences(pElem, sentences)",
      pElem,
      sentences
    );
    let copiedSentences = createDeepCopy(sentences);
    let walk = document.createTreeWalker(
      pElem,
      NodeFilter.SHOW_TEXT,
      null,
      false
    );
    let sentenceIndexInParagraph = 0;
    let copyOfSentenceIndex = sentenceIndex;
    while ((n = walk.nextNode())) {
      sentenceIndexInParagraph = await setSentencesHelper(
        n,
        copiedSentences,
        sentenceIndexInParagraph
      );
    }
    for (let i = 0; i < sentences.length; i++) {
      id = identPrefix + copyOfSentenceIndex;
      let sentenceNodes = pElem.getElementsByClassName(id);
      await setWords(sentenceNodes, sentences[i], copyOfSentenceIndex);
      copyOfSentenceIndex++;
    }
  }

  function addSentencesToTextToRead(sentences) {
    console.log(
      "Pericles.googleDrivePreview.addSentencesToTextToRead(sentences)",
      sentences
    );
    for (let i = 0; i < sentences.length; i++) {
      if (sentences[i]) {
        textsToRead.push({
          text: sentences[i]
        });
      }
    }
  }

  async function setWords(sentenceElems, sentence, senIndex) {
    console.log(
      "Pericles.setWords(sentenceElems, sentence, senIndex)",
      sentenceElems,
      sentence,
      senIndex
    );
    try {
      let wordIndex = 0;
      let ttsWords = sentence.split(" ");
      for (let i = 0; i < sentenceElems.length; i++) {
        let nrSentence = $(sentenceElems[i]);
        let words = $(nrSentence)
          .text()
          .split(" ");
        $(nrSentence).empty();
        $.each(words, (i, v) => {
          let word = processHtmlText(v).trim();
          if (word) {
            let currTtsWord = ttsWords[wordIndex];
            if (currTtsWord.indexOf(word) === 0) {
              let nrWord = document.createElement(wordTag);
              $(nrWord).addClass(identPrefix + senIndex + "w" + wordIndex);
              $(nrWord).text(word);
              $(nrSentence).append(nrWord);
              ttsWords[wordIndex] = ttsWords[wordIndex].substring(word.length);
              if (!ttsWords[wordIndex]) {
                wordIndex++;
              }
            } else {
              $(nrSentence).append(document.createTextNode(word));
            }
          }
          if (i < words.length - 1) {
            $(nrSentence).append(document.createTextNode(" "));
          }
        });
      }
    } catch (err) {
      console.error("Pericles.setWords", err);
    }
  }

  function createDeepCopy(array) {
    console.log("Pericles.googleDrivePreview.createDeepCopy(array)", array);
    let deepCopy = [];
    for (let i = 0; i < array.length; i++) {
      deepCopy.push(array[i]);
    }
    return deepCopy;
  }

  async function setSentencesHelper(n, sentences, sentenceIndexInParagraph) {
    console.log(
      "Pericles.googleDrivePreview.setSentencesHelper(n, sentences, sentenceIndexInParagraph)"
    );
    let nrSentence = document.createElement(senTag);
    $(nrSentence).addClass(identPrefix / +sentenceIndex);
    if (!sentences[sentenceIndexInParagraph]) {
      return sentenceIndexInParagraph;
    }
    let ttsSentence = sentences[sentenceIndexInParagraph].trim();
    let nodeText = processHtmlText($(n).text()).trim();
    if (!nodeText) {
      return sentenceIndexInParagraph;
    }
    if (nodeText.length > ttsSentence.length) {
      let splitIndex = await findIndexOfSentence(n, ttsSentence);
      let remainder = n.splitText(splitIndex);
      $(n).wrap(nrSentence);
      sentences[sentenceIndexInParagraph] = ttsSentence.substring(
        processHtmlText($(n).text()).trim().length
      );
      sentenceIndexInParagraph++;
      sentenceIndex++;
    } else {
      if (ttsSentence.indexOf(nodeText) === 0) {
        $(n).wrap(nrSentence);
        sentences[sentenceIndexInParagraph] = ttsSentence
          .substring(nodeText.length)
          .trim();
        if (!sentences[sentenceIndexInParagraph]) {
          sentenceIndexInParagraph++;
          sentenceIndex++;
        }
      }
    }
    return sentenceIndexInParagraph;
  }

  function findIndexOfSentence(textNode, sentence) {
    console.log(
      "Pericles.googleDrivePreview.findIndexOfSentence(textNode, sentence)",
      textNode,
      sentence
    );
    return new Promise(resolve => {
      let numTtsWords = sentence.split(" ").length;
      let nodeWords = $(textNode)
        .text()
        .split(" ");
      let nodeWordsIndex = 0;
      let resultIndex = 0;
      while (numTtsWords > 0 && nodeWordsIndex < nodeWords.length) {
        resultIndex++;
        while (
          !nodeWords[nodeWordsIndex] ||
          !nodeWords[nodeWordsIndex].trim()
        ) {
          nodeWordsIndex++;
          resultIndex++;
        }
        resultIndex += nodeWords[nodeWordsIndex].length;
        nodeWordsIndex++;
        numTtsWords--;
      }
      resolve(resultIndex);
    }).catch(err => {
      console.error("Pericles.googleDrivePreview.findIndexOfSentence", err);
    });
  }

  function getTexts() {
    console.log("Pericles.googleDrivePreview.getTexts()");
    let texts = $("p", this)
      .get()
      .map(getInnerText)
      .filter(isNotEmpty);
    return fixParagraphs(texts);
  }
};
export default doc;
