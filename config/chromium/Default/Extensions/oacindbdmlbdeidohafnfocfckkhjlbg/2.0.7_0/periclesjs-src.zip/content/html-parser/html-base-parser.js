import {
  processHtmlText,
  senTag,
  wordTag,
  paraTag,
  identPrefix,
  removePSTags,
  asyncForEach
} from "./html-parser.common";

export default class HTMLBaseParser {
  constructor() {
    this.textsToRead = [];
    this.sentenceIndex = 0;
  }

  async reset() {
    this.textsToRead = [];
    this.sentenceIndex = 0;
    await removePSTags();
  }
}
