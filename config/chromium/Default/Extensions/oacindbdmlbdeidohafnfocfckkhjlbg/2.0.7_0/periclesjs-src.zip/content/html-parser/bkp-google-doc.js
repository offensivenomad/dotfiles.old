const $ = require('jquery');
const nlp = require('../../external/compromise.min.js');
const googleDocsUtil = require('./google-doc-utils.js');
const senTag = 'ps-sen';
const wordTag = 'ps-wor';
const paraTag = 'ps-par';
const identPrefix = 's';

const { processHtmlText } = require('./html-parser.common.js');

let doc = function() {
    this.type = "googleDoc";
    let textsToRead = [];
    let sentenceIndex = 0;
    let viewport = $(".kix-appview-editor").get(0);
    let pages = $(".kix-page");
    let selectionState;
    let pageIndex = 0;

	this.setBlock = (container) => {
		console.log('Pericles.googleDoc.setBlock', container);
		this.container = container;
	}

    this.scrollToAdjacentPage = async function(direction) {
		console.log('Pericles.googleDoc.scrollToAdjacentPage(direction)', direction);

        return new Promise((resolve) => {
            pages = $(".kix-page");
            let page = null;
            if (direction === 'next') {
                if (pageIndex < pages.length - 1 && pageIndex !== -1) {
                    page = pages[pageIndex + 1];
                } else {
                    resolve('ERR');
                }
            } else {
                if (pageIndex > 0) {
                    page = pages[pageIndex - 1];
                } else if (pageIndex === -1) {
                    page = pages[pages.length - 2];
                }
                else {
                    resolve('ERR');
                }
            }
			// let t;
			// console.log('Pericles.googleDoc.viewport.starting');
			// $(viewport).scroll(() => {
				// clearTimeout(t);
				// t = setTimeout(() => {
					// console.log('Pericles.googleDoc.viewport.resolving');
					// resolve('next');
					// $(viewport).unbind('scroll');
				// }, 300);
			// });
//
            viewport.scrollTop = $(page).position().top;
			resolve('next');
        })
		.catch((err) => {
			console.error('Pericles.googleDoc.scrollToAdjacentPage.error', err);
		});
    }

    this.scrollToSentence = async function(elem) {
		console.log('Pericles.googleDoc.scrollToSentence(elem)', elem);
		
        let offset = -(await calculateScrollOffset(elem));
        if (pageIndex === -1) {
            viewport.scrollTop = offset + $(pages[pages.length - 1]).position().top;
        } else {
            viewport.scrollTop = offset + $(pages[pageIndex]).position().top;
        }
    }

    function calculateScrollOffset(elem) {
		console.log('Pericles.googleDoc.calculateScrollOffset(elem)', elem);

        return new Promise((resolve) => {
            let elemOffset = $(elem).offset().top;
            let offset = 0;
            elem = $(elem);
            while (elem.offsetParent() && elem.offsetParent().css('position') === 'relative' && !elem.offsetParent().hasClass('kix-page')) {
                offset = offset + elem.offsetParent().offset().top;
                elem = elem.offsetParent();
            }
            resolve(elemOffset - offset);
        })
            .catch((err) => {
				console.error('Pericles.googleDoc.calculateScrollOffset.error', err);
            });
    }

    function getCurrentIndex() {
		console.log('Pericles.googleDoc.getCurrentIndex()');

        let index = 0;
        for (let i = 0; i < pages.length; i++) {
            if (pages.eq(i).position().top > viewport.scrollTop + $(viewport).height() / 2) {
                index = i;
                break;
            }
        }
        return index - 1;
    }

	this.reset = async () => {
		console.log('Pericles.googleDoc.reset()');
		await reset();
		await removeNRTags();
		this.container = false;
	}

    this.getTexts = async function(op = 'tts') {
		console.log('Pericles.googleDoc.getTexts()');

        pageIndex = getCurrentIndex();
        return new Promise(async (resolve) => {
            await reset();
            await removeNRTags();
            resolve();
        })
            .then(() => {
                return new Promise(async (resolve) => {
                    let promises = [];
                    promises.push(
                        await getTextsOfPage(pageIndex, op)
                    );
                    resolve(promises);
                })
            })
            .then(promises => {
                return Promise.all(promises);
            })
            .then(() => {
                return new Promise((resolve) => {
                    let err = null;
                    if (op !== 'tts') {
                        if (textsToRead.length === 0) {
                            err = 'ERR_NO_TEXT';
                        }
                    }
                    resolve({err: err, res: textsToRead});
                });
            })
            .catch((err) => {
				console.error('Pericles.googleDoc.getTexts.error', err);
            });
    }

    function getTextsOfPage(index, op = 'tts') {
		console.log('Pericles.googleDoc.getTextsOfPage(index, op)', index, op);

        return new Promise(async (resolve) => {
            let page = pages.get(index);
            if (page) {
                let oldScrollTop = viewport.scrollTop;
                viewport.scrollTop = $(page).position().top;
                await processSentencesInParagraphs(page, op);
                viewport.scrollTop = oldScrollTop;
            }
            resolve();
        })
            .catch((err) => {
				console.error('Pericles.googleDoc.getTextsOfPage.error', err);
            });
    }

    function processSentencesInParagraphs(page, op = 'tts') {
		console.log('Pericles.googleDoc.processSentencesInParagraphs(page, op)', page, op);

        return Promise.resolve()
            .then(async () => {
                let paragraphs = $(page).find('.kix-paragraphrenderer').get();
                for (let i = 0; i < paragraphs.length; i++) {
                    let processedHtmlText = processHtmlText($(paragraphs[i]).text()).trim();
                    if (op === 'tts') {
                        let sentences = (nlp(processedHtmlText).sentences().data()).map(s => s.text.trim());
                        await setSentences(paragraphs[i], sentences, sentenceIndex);
                        addSentencesToTextToRead(sentences);
                    } else {
                        addSentencesToTextToRead([processedHtmlText]);
                    }
                    //    
                }
            })
            .catch((err) => {
				console.error('Pericles.googleDoc.processSentencesInParagraphs.error', err);
            });
    }

    function addSentencesToTextToRead(sentences) {
		console.log('Pericles.googleDoc.addSentencesToTextToRead(sentences)', sentences);

        for (let i = 0; i < sentences.length; i++) {
            if (sentences[i]) {
                textsToRead.push({text: sentences[i]});
            }
        }
    }

    async function setSentences(pElem, sentences) {
		console.log('Pericles.googleDoc.setSentences(pElem, sentences)', pElem, sentences);

        let copiedSentences = createDeepCopy(sentences);
        let walk = document.createTreeWalker(pElem, NodeFilter.SHOW_TEXT, null, false);
        let sentenceIndexInParagraph = 0;
        let copyOfSentenceIndex = sentenceIndex;
		let n, id;

        while (n = walk.nextNode()) {
            sentenceIndexInParagraph = await setSentencesHelper(n, copiedSentences, sentenceIndexInParagraph);
        }
        for (let i = 0; i < sentences.length; i++) {
            id = identPrefix + copyOfSentenceIndex;
            let sentenceNodes = pElem.getElementsByClassName(id);
            await setWords(sentenceNodes, sentences[i], copyOfSentenceIndex);
            copyOfSentenceIndex++;
        }
    }

    async function setWords(sentenceElems, sentence, senIndex) {
		console.log('Pericles.googleDoc.setWords(sentenceElems, sentence, senIndex)', sentenceElems, sentence, senIndex);

        try {
            let wordIndex = 0;
            let ttsWords = sentence.split(" ");
            for (let i = 0; i < sentenceElems.length; i++) {
                let nrSentence = $(sentenceElems[i]);
                let words = $(nrSentence).text().split(" ");
                $(nrSentence).empty();
                $.each(words, (i, v) => {
                    let word = processHtmlText(v).trim();
                    if (word) {
                        let currTtsWord = ttsWords[wordIndex];
                        if (currTtsWord.indexOf(word) === 0) {
                            let nrWord = document.createElement(wordTag);
                            $(nrWord).addClass(identPrefix + senIndex + 'w' + wordIndex);
                            $(nrWord).text(word);
                            $(nrSentence).append(nrWord);
                            ttsWords[wordIndex] = ttsWords[wordIndex].substring(word.length);
                            if (!ttsWords[wordIndex]) {
                                wordIndex++;
                            }
                        } else {
                            $(nrSentence).append(document.createTextNode(word));
                        }
                    }
                    if (i < words.length - 1) {
                        $(nrSentence).append(document.createTextNode(" "));
                    }
                });
            }
        } catch (err) {
			console.error('Pericles.googleDoc.setWords.error', err);
        }
    }
	
    function createDeepCopy(array) {
		console.log('Pericles.googleDoc.createDeepCopy(array)', array);

        let deepCopy = [];
        for (let i = 0; i < array.length; i++) {
            deepCopy.push(array[i]);
        }
        return deepCopy;
    }

    async function setSentencesHelper(n, sentences, sentenceIndexInParagraph) {
		console.log('Pericles.googleDoc.setSentencesHelper(n, sentences, sentenceIndexInParagraph)', n, sentences, sentenceIndexInParagraph);

        let nrSentence = document.createElement(senTag);
        $(nrSentence).addClass(identPrefix + sentenceIndex);
        if (!sentences[sentenceIndexInParagraph]) {
            return sentenceIndexInParagraph;
        }
        let ttsSentence = sentences[sentenceIndexInParagraph].trim();
        let nodeText = processHtmlText($(n).text()).trim();
        if (!nodeText) {
            return sentenceIndexInParagraph;
        }
        if (nodeText.length > ttsSentence.length) {
            let splitIndex = await findIndexOfSentence(n, ttsSentence);
            let remainder = n.splitText(splitIndex);
            $(n).wrap(nrSentence);
            sentences[sentenceIndexInParagraph] = ttsSentence.substring(processHtmlText($(n).text()).trim().length);
            sentenceIndexInParagraph++;
            sentenceIndex++;
        } else {
            if (ttsSentence.indexOf(nodeText) === 0) {
                $(n).wrap(nrSentence);
                sentences[sentenceIndexInParagraph] = ttsSentence.substring(nodeText.length).trim();
                if (!sentences[sentenceIndexInParagraph]) {
                    sentenceIndexInParagraph++;
                    sentenceIndex++;
                }
            }
        }
        return sentenceIndexInParagraph;
    }

    function findIndexOfSentence(textNode, sentence) {
		console.log('Pericles.googleDoc.findIndexOfSentence(textNode, sentence)');

        return new Promise((resolve) => {
            let numTtsWords = sentence.split(" ").length;
            let nodeWords = $(textNode).text().split(" ");
            let nodeWordsIndex = 0;
            let resultIndex = 0;
            while (numTtsWords > 0 && nodeWordsIndex < nodeWords.length) {
                resultIndex++;
                while (!nodeWords[nodeWordsIndex] || !nodeWords[nodeWordsIndex].trim()) {
                    nodeWordsIndex++;
                    resultIndex++;
                }
                resultIndex += nodeWords[nodeWordsIndex].length;
                nodeWordsIndex++;
                numTtsWords--;
            }
            resolve(resultIndex);
        })
            .catch((err) => {
				console.error('Pericles.googleDoc.findIndexOfSentence.error', err);
            });
    }

    async function removeNRTags() {
		console.log('Pericles.googleDoc.removePSTags()');
		
        try {
            await replaceNRTagsWithTextNodes(senTag);
        } catch (err) {
			console.error('Pericles.googleDoc.removePSTags.error', err);
        }
    }

	
    function replaceNRTagsWithTextNodes(tagName) {
		console.log('Pericles.googleDoc.replaceNRTagsWithTextNodes(tagName)', tagName);

        return new Promise(async (resolve) => {
            let nodes = $(document.body).find(tagName).get();
            for (let i = 0; i < nodes.length; i++) {
                await replaceNRTagWithTextNode(nodes[i]);
            }
            resolve();
        })
    }

    function replaceNRTagWithTextNode(node) {
		console.log('Pericles.googleDoc.replaceNRTagWithTextNode(node)', node);
		
        return new Promise((resolve) => {
            let text = $(node).text();
            $(node).replaceWith(document.createTextNode(text));
            resolve();
        })
            .catch((err) => {
				console.error('Pericles.googleDoc.replaceNRTagWithTextNode.err', err);
            });
    }

    function reset() {
		console.log('Pericles.googleDoc.reset()');

        return Promise.resolve()
            .then(() => {
                textsToRead = [];
                sentenceIndex = 0;
            }).catch(err => {
				console.error('Pericles.googleDoc.reset.error', err);
            });
    }

    function getTexts() {
		console.log('Pericles.googleDoc.getTexts()');

        return $(".kix-paragraphrenderer", this).get()
            .map(getInnerText)
            .filter(isNotEmpty);
    }

    function setSentence(elem, processedHtmlText) {
		console.log('Pericles.googleDoc.setSentence(elem, processedHtmlText)', elem, processedHtmlText);

        try {
            let wordIndex = 0;
            let ttsWords = processedHtmlText.split(" ");
            let walk = document.createTreeWalker(elem, NodeFilter.SHOW_TEXT, null, false);
            while (n = walk.nextNode()) {
                let nrSentence = document.createElement(senTag);
                $(nrSentence).addClass(identPrefix + sentenceIndex);
                $(n).wrap(nrSentence);
            }
            let nrSentences = document.getElementsByClassName(identPrefix + sentenceIndex);
            for (let i = 0; i < nrSentences.length; i++) {
                let nrSentence = nrSentences[i];
                let words = $(nrSentence).text().split(" ");
                $(nrSentence).empty();
                $.each(words, (i, v) => {
                    let word = processHtmlText(v).trim();
                    if (word) {
                        let currTtsWord = ttsWords[wordIndex];
                        if (currTtsWord.indexOf(word) === 0) {
                            let nrWord = document.createElement(wordTag);
                            $(nrWord).addClass(identPrefix + sentenceIndex + 'w' + wordIndex);
                            $(nrWord).text(word);
                            $(nrSentence).append(nrWord);
                            ttsWords[wordIndex] = ttsWords[wordIndex].substring(word.length);
                            if (!ttsWords[wordIndex]) {
                                wordIndex++;
                            }
                        } else {
                            $(nrSentence).append(document.createTextNode(word));
                        }
                    }
                    if (i < words.length - 1) {
                        $(nrSentence).append(document.createTextNode(" "));
                    }
                });
            }
        } catch (err) {
			console.error('Pericles.googleDoc.setSentence.error', err);
        }
    }

    function getSelectedText() {
		console.log('Pericles.googleDoc.getSelectedText()');

        let doc = googleDocsUtil.getGoogleDocument();
        if (!selectionState) selectionState = {caret: doc.caret.index, prev: [], text: doc.selectedText};
        if (selectionState.caret != doc.caret.index) {
            selectionState.caret = doc.caret.index;
            selectionState.prev.push(selectionState.text);
            selectionState.text = doc.selectedText;
            selectionState.prev = selectionState.prev.filter(function(text) {
                let index = selectionState.text.indexOf(text);
                if (index != -1) selectionState.text = selectionState.text.slice(0, index) + selectionState.text.slice(index + text.length);
                return index != -1;
            })
        }
        return selectionState.text;
    }
}

module.exports = doc;
