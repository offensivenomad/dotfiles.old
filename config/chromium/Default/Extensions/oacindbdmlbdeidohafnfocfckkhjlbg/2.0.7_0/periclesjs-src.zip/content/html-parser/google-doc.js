import $ from "jquery";
import nlp from "compromise";
import AbstractDocParser from "./abstract-doc-parser";
import {
  processHtmlText,
  senTag,
  wordTag,
  identPrefix,
  createDeepCopy,
  setSentencesHelper
} from "./html-parser.common.js";

let instance = null;
export default class GoogleDoc extends AbstractDocParser {
  constructor() {
    super();
    if (!instance) instance = this;

    this.type = "googleDoc";
    this.pageIdent = ".kix-page";
    this.paraIdent = ".kix-paragraphrenderer";
    this.viewportIdent = ".kix-appview-editor";

    return instance;
  }

  async getTexts(op = "tts") {
    // console.log('Pericles.googleDoc.getTexts()');
    return new Promise(async resolve => {
      await this.reset();
      resolve();
    })
      .then(() => {
        return new Promise(async resolve => {
          let promises = [];
          promises.push(await this.getTextsOfPage(this.pageIndex, op));
          resolve(promises);
        });
      })
      .then(promises => {
        return Promise.all(promises);
      })
      .then(() => {
        return new Promise(resolve => {
          let err = null;
          if (op !== "tts") {
            if (this.textsToRead.length === 0) {
              err = "ERR_NO_TEXT";
            }
          }
          resolve({ err: err, res: this.textsToRead });
        });
      })
      .catch(err => {
        console.error("Pericles.googleDoc.getTexts.error", err);
      });
  }

  async getTextsOfPage(index, op = "tts") {
    // console.log('Pericles.googleDoc.getTextsOfPage(index, op)', index, op);
    try {
      this.page = this.pages[index];
      if (this.page) {
        let oldScrollTop = this.viewport.scrollTop;
        this.viewport.scrollTop = $(this.page).position().top;
        await this.processSentencesInParagraphs(this.page, op);
        this.viewport.scrollTop = oldScrollTop;
      }
      return true;
    } catch (e) {
      console.error("Pericles.googleDoc.getTextsOfPage.error", e);
    }
  }

  async processSentencesInParagraphs(page, op = "tts") {
    // console.log('Pericles.googleDoc.processSentencesInParagraphs(page, op)', page, op);

    return Promise.resolve()
      .then(async () => {
        let paragraphs = $(page)
          .find(".kix-paragraphrenderer")
          .get();
        console.log("processSentencesInParagraphs - paragraphs", paragraphs);
        for (let i = 0; i < paragraphs.length; i++) {
          let processedHtmlText = processHtmlText(
            $(paragraphs[i]).text()
          ).trim();
          console.log(
            "processSentencesInParagraphs - processedHtmlText",
            processedHtmlText
          );
          if (op === "tts") {
            let sentences = nlp(processedHtmlText)
              .sentences()
              .data()
              .map(s => s.text.trim());
            console.log("processSentencesInParagraphs - sentences", sentences);
            await this.setSentences(
              paragraphs[i],
              sentences,
              this.sentenceIndex
            );
            this.addSentencesToTextToRead(sentences);
          } else {
            this.addSentencesToTextToRead([processedHtmlText]);
          }
          //
        }
      })
      .catch(err => {
        console.error(
          "Pericles.googleDoc.processSentencesInParagraphs.error",
          err
        );
      });
  }

  addSentencesToTextToRead(sentences) {
    // console.log('Pericles.googleDoc.addSentencesToTextToRead(sentences)', sentences);
    for (let i = 0; i < sentences.length; i++) {
      if (sentences[i]) {
        this.textsToRead.push({ text: sentences[i] });
      }
    }
  }

  async setSentences(pElem, sentences) {
    // console.log('Pericles.googleDoc.setSentences(pElem, sentences)', pElem, sentences);
    let copiedSentences = createDeepCopy(sentences);
    let walk = document.createTreeWalker(
      pElem,
      NodeFilter.SHOW_TEXT,
      null,
      false
    );
    let copyOfSentenceIndex = this.sentenceIndex;
    let n, id;
    let sentenceIndexInParagraph = 0;
    let output = {};
    while ((n = walk.nextNode())) {
      console.log("setSentences - walk.nextNode()", n);
      output = setSentencesHelper(
        n,
        copiedSentences[sentenceIndexInParagraph],
        sentenceIndexInParagraph,
        this.sentenceIndex
      );

      copiedSentences[sentenceIndexInParagraph] = output.senText;
      sentenceIndexInParagraph = output.index;
      this.sentenceIndex = output.sentenceIndex;
    }
    for (let i = 0; i < sentences.length; i++) {
      id = identPrefix + copyOfSentenceIndex;
      let sentenceNodes = pElem.getElementsByClassName(id);
      await this.setWords(sentenceNodes, sentences[i], copyOfSentenceIndex);
      copyOfSentenceIndex++;
    }
  }

  async setWords(sentenceElems, sentence, senIndex) {
    return false;
    // console.log('Pericles.googleDoc.setWords(sentenceElems, sentence, senIndex)', sentenceElems, sentence, senIndex);

    let wordIndex = 0;
    try {
      let ttsWords = sentence.split(" ");
      for (
        let sentenceKey = 0;
        sentenceKey < sentenceElems.length;
        sentenceKey++
      ) {
        let nrSentence = $(sentenceElems[sentenceKey]);
        let words = $(nrSentence)
          .text()
          .split(" ");
        $(nrSentence).empty();
        $.each(words, (wordKey, wordVal) => {
          const word = processHtmlText(wordVal).trim();
          if (word) {
            let currTtsWord = ttsWords[wordIndex];
            if (currTtsWord.indexOf(word) === 0) {
              let nrWord = document.createElement(wordTag);
              $(nrWord).addClass(identPrefix + senIndex + "w" + wordIndex);
              $(nrWord).text(word);
              $(nrSentence).append(nrWord);
              ttsWords[wordIndex] = ttsWords[wordIndex].substring(word.length);
              if (!ttsWords[wordIndex]) {
                wordIndex++;
              }
            } else {
              $(nrSentence).append(document.createTextNode(word));
            }
          }
          if (wordKey < words.length - 1) {
            $(nrSentence).append(document.createTextNode(" "));
          }
        });
      }
    } catch (err) {
      console.error("Pericles.googleDoc.setWords.error", err);
    }
  }

  async setSentencesHelper2(n, sentences, sentenceIndexInParagraph) {
    // console.log('Pericles.googleDoc.setSentencesHelper(n, sentences, sentenceIndexInParagraph)', n, sentences, sentenceIndexInParagraph);

    let nrSentence = document.createElement(senTag);
    $(nrSentence).addClass(identPrefix + this.sentenceIndex);
    if (!sentences[sentenceIndexInParagraph]) {
      return sentenceIndexInParagraph;
    }
    let ttsSentence = sentences[sentenceIndexInParagraph].trim();
    let nodeText = processHtmlText($(n).text()).trim();
    if (!nodeText) {
      return sentenceIndexInParagraph;
    }
    if (nodeText.length > ttsSentence.length) {
      // let splitIndex = await this.findIndexOfSentence(n, ttsSentence);
      // let remainder = n.splitText(splitIndex);
      $(n).wrap(nrSentence);
      sentences[sentenceIndexInParagraph] = ttsSentence.substring(
        processHtmlText($(n).text()).trim().length
      );
      sentenceIndexInParagraph++;
      this.sentenceIndex++;
    } else {
      if (ttsSentence.indexOf(nodeText) === 0) {
        $(n).wrap(nrSentence);
        sentences[sentenceIndexInParagraph] = ttsSentence
          .substring(nodeText.length)
          .trim();
        if (!sentences[sentenceIndexInParagraph]) {
          sentenceIndexInParagraph++;
          this.sentenceIndex++;
        }
      }
    }
    return sentenceIndexInParagraph;
  }

  findIndexOfSentence(textNode, sentence) {
    // console.log('Pericles.googleDoc.findIndexOfSentence(textNode, sentence)');
    return new Promise(resolve => {
      let numTtsWords = sentence.split(" ").length;
      let nodeWords = $(textNode)
        .text()
        .split(" ");
      let nodeWordsIndex = 0;
      let resultIndex = 0;
      while (numTtsWords > 0 && nodeWordsIndex < nodeWords.length) {
        resultIndex++;
        while (
          !nodeWords[nodeWordsIndex] ||
          !nodeWords[nodeWordsIndex].trim()
        ) {
          nodeWordsIndex++;
          resultIndex++;
        }
        resultIndex += nodeWords[nodeWordsIndex].length;
        nodeWordsIndex++;
        numTtsWords--;
      }
      resolve(resultIndex);
    }).catch(err => {
      console.error("Pericles.googleDoc.findIndexOfSentence.error", err);
    });
  }

  setSentence(elem, processedHtmlText) {
    // console.log('Pericles.googleDoc.setSentence(elem, processedHtmlText)', elem, processedHtmlText);
    try {
      let wordIndex = 0;
      let n;
      let ttsWords = processedHtmlText.split(" ");
      let walk = document.createTreeWalker(
        elem,
        NodeFilter.SHOW_TEXT,
        null,
        false
      );
      while ((n = walk.nextNode())) {
        let nrSentence = document.createElement(senTag);
        $(nrSentence).addClass(identPrefix + this.sentenceIndex);
        $(n).wrap(nrSentence);
      }
      /* let nrSentences = document.getElementsByClassName( */
      //   identPrefix + this.sentenceIndex
      // );
      // for (let i = 0; i < nrSentences.length; i++) {
      //   let nrSentence = nrSentences[i];
      //   let words = $(nrSentence)
      //     .text()
      //     .split(" ");
      //   $(nrSentence).empty();
      //   $.each(words, (i, v) => {
      //     let word = processHtmlText(v).trim();
      //     if (word) {
      //       let currTtsWord = ttsWords[wordIndex];
      //       if (currTtsWord.indexOf(word) === 0) {
      //         let nrWord = document.createElement(wordTag);
      //         $(nrWord).addClass(
      //           identPrefix + this.sentenceIndex + "w" + wordIndex
      //         );
      //         $(nrWord).text(word);
      //         $(nrSentence).append(nrWord);
      //         ttsWords[wordIndex] = ttsWords[wordIndex].substring(word.length);
      //         if (!ttsWords[wordIndex]) {
      //           wordIndex++;
      //         }
      //       } else {
      //         $(nrSentence).append(document.createTextNode(word));
      //       }
      //     }
      //     if (i < words.length - 1) {
      //       $(nrSentence).append(document.createTextNode(" "));
      //     }
      //   });
      /* } */
    } catch (err) {
      console.error("Pericles.googleDoc.setSentence.error", err);
    }
  }
}
