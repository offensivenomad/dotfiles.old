import $ from "jquery";
let t;

export const getSectionKey = () => {
  console.log("Pericles.speech.ui.getSectionKey");
  return 1;
};

export const getElemBySectionKey = key => {
  const ident = `ps-sen.s${key}`;
  const elem = $(ident).last();
  console.log("Pericles.speech.ui.getElemBySectionKey", key, ident, elem);

  return elem;
};

export const wordTrackerRemove = () => {
  const wordTrackerCls = "_pericles_word_track";
  $("ps-wor").removeClass(wordTrackerCls);
};

export const scrollToAdjacentPage = (page, viewport) => {
  console.log(
    "Pericles.speech.ui.scrollToAdjacentPage(page, viewport)",
    page,
    viewport
  );
  clearTimeout(t);
  $(viewport).stop();
  return new Promise(resolve => {
    viewport.scrollTop = page.offsetTop;
    resolve("next");
    // $(viewport).stop();
    // $(viewport).animate({
    //     scrollTop: page.offsetTop
    // }, 0, () => {
    //     console.log('Pericles.speech.ui.scrollToAdjacentPage - complete');
    //
    //     resolve('next');
    // });
  }).catch(err => {
    console.error("Pericles.viewerDoc.scrollToAdjacentPage.error", err);
  });
};

export const scrollToSection = async (key, viewport, page) => {
  console.log("Pericles.speech.scrollToSection", key, viewport);
  clearTimeout(t);
  try {
    const elem = getElemBySectionKey(key).parent();
    viewport =
      viewport || window.document.documentElement || window.document.body;
    console.log(
      "Pericles.speech.scrollToSection.elem",
      elem,
      elem.offset(),
      elem.position()
    );
    if (elem.length) {
      const body = $(viewport);
      // const pageOffsetTop = page.offsetTop + (page.offsetTop - viewport.scrollTop)
      let elemOffset;
      if (page) {
        elemOffset = Math.round(page.offsetTop + elem[0].parentNode.offsetTop);
      } else {
        elemOffset = elem.offset().top;
        // elemOffset = viewport.scrollTop + elem.offset().top;
      }

      elemOffset = Math.round(elemOffset);

      console.log(
        "Pericles.speech.scrollToSection.elemOffset, viewport",
        elemOffset,
        body
      );

      body.stop();
      t = setTimeout(() => {
        body.animate(
          {
            scrollTop: elemOffset - 200
          },
          1200
        );
      }, 1000);
    }
  } catch (e) {
    console.error("Pericles.speech.render.autoscroll", e);
  }

  return Promise.resolve();
};

export const wordTracker = index => {
  console.log("Pericles.speech.wordTracker(index)", index);
  const wordTrackerCls = "_pericles_word_track";
  const key = getSectionKey();
  const elem = getElemBySectionKey();
  const word = elem.find(`ps-wor.s${key}w${index}`);

  if (word.length) {
    wordTrackerRemove();
  }

  word.addClass(wordTrackerCls);
  console.log("Pericles.speech.wordTracker.word", word);
};

export const unHighlightSentence = () => {
  console.log("Pericles.speech.ui.unHighlightSentence");
  $("ps-sen").removeClass("_pericles_pulse");
};

export const highlightSentence = key => {
  console.log("Pericles.speech.ui.hightlightSentence(key)", key);
  unHighlightSentence();

  const elem = $(`ps-sen[class="s${key}"]`);
  elem.addClass("_pericles_pulse");
};
