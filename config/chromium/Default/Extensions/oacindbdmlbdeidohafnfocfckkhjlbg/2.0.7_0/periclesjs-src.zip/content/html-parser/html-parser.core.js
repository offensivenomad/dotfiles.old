import { sites } from "./sites/sites";
import $ from "jquery";
import DefaultParser from "./html-parser.website";
import GoogleDocParser from "./google-doc";
import GoogleDriveParser from "./google-drive-doc.js";
import GoogleDrivePreviewParser from "./google-drive-preview.js";
import ViewerDocParser from "./viewer-doc.js";

const self = {
  parser: {},
  getParserByUrl: () => {
    const methods = [
      {
        parser: GoogleDocParser,
        check: window.location.hostname === "docs.google.com"
      },
      {
        parser: GoogleDriveParser,
        cond: [
          $(".drive-viewer-paginated-scrollable").length,
          window.location.hostname === "docs.google.com"
        ]
      },
      {
        parser: GoogleDrivePreviewParser,
        cond: [
          !$(".drive-viewer-paginated-scrollable").length,
          window.location.hostname === "docs.google.com"
        ]
      },
      {
        parser: ViewerDocParser,
        check: window.location.href.indexOf("ViewerJS") !== -1
      },
      {
        parser: DefaultParser,
        check: true
      }
    ];
    const candidate = methods.find(method => {
      console.log("parser.method", method);
      if (typeof method.check === "object")
        return !!method.every(cond => cond === true);
      else return !!method.check;
    });
    self.parser = new candidate["parser"]();
    return self.parser;
  },

  filterSpecialSite: url => {
    console.log("Pericles.htmlParser.filterSpecialSite()->url", url);
    return sites.filter(site => {
      return url.indexOf(site.host) !== -1;
    })[0];
  },

  specialSite: hostName => {
    return self.filterSpecialSite(hostName);
  },

  specialSiteGetBlock: site => {
    let q;
    if (site.attr === "id") {
      q = `${site.tagName}#${site.value.join(" ")}`;
    } else if (site.attr === "class") {
      q = `${site.tagName}.${site.value.join(" ")}`;
    } else {
      if (site.attr && site.value)
        q = `${site.tagName}[${site.attr}="${site.value.join(" ")}"]`;
      else q = `${site.tagName}`;
    }

    return $(q);
  },

  specialSiteTagsToQuery: tags => {
    return tags
      .map(tag => `${tag.tagName}[${tag.attr}="${tag.value.join(" ")}"]`)
      .join(", ");
  }
};

export default self;
