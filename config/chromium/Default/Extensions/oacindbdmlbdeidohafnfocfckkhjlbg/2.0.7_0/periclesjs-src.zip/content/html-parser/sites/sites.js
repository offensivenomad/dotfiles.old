export const sites = [
  {
    host: "twitch.tv",
    tagName: "div",
    attr: "role",
    value: ["log"],
    paragraph: {
      tagName: "div",
      attr: "class",
      value: "chat-line__message"
    }
  },
  {
    host: "rt.com",
    tagName: "div",
    attr: "class",
    value: ["article"]
  },
  {
    host: "wikipedia.org",
    tagName: "div",
    attr: "id",
    value: ["bodyContent"],
    junk: [
      { tagName: "table", attr: "class", value: ["infobox"] },
      { tagName: "table", attr: "class", value: ["vertical-navbox"] },
      { tagName: "div", attr: "role", value: ["navigation"] },
      { tagName: "div", attr: "class", value: ["reflist"] },
      { tagName: "div", attr: "id", value: ["mw-panel"] },
      { tagName: "div", attr: "id", value: ["mw-head"] },
      { tagName: "div", attr: "class", value: ["thumbcaption"] },
      { tagName: "div", attr: "class", value: ["shortdescription"] },
      { tagName: "div", attr: "id", value: ["toc"] }
    ]
  },
  {
    host: "nytimes.com",
    tagName: "article",
    attr: "id",
    value: ["story"],
    junk: [
      { tagName: "div", attr: "id", value: ["sponsor-wrapper"] },
      { tagName: "div", attr: "class", value: ["bottom-of-article"] },
      { tagName: "div", attr: "id", value: ["bottom-wrapper"] },
      { tagName: "p", attr: "itemprop", value: ["author creator"] },
      { tagName: "div", attr: "id", value: ["top-wrapper"] },
      { tagName: "time" },
      { tagName: "figure" }
    ]
  },
  {
    host: "timesnewroman.ro",
    tagName: "div",
    attr: "class",
    value: ["white-mask"],
    junk: []
  },
  {
    host: "kmkz.ro",
    tagName: "div",
    attr: "class",
    value: ["entry-content"],
    junk: []
  },
  {
    host: "ziaruldeiasi.ro",
    tagName: "div",
    attr: "class",
    value: ["articol-content"],
    junk: []
  },
  {
    host: "digi24.ro",
    tagName: "div",
    attr: "class",
    value: ["entry", "data-app-meta", "data-app-meta-article"],
    junk: []
  },
  {
    host: "twitch.tv",
    tagName: "div",
    attr: "role",
    value: ["log"],
    junk: []
  },
  {
    host: "docs.google.com",
    tagName: "div",
    attr: "class",
    // value: ['kix-paginateddocumentplugin'],
    value: ["kix-page-content-wrapper"],
    // value: ['kix-appview-editor-container'],
    paragraph: {
      tagName: "div",
      attr: "class",
      value: "kix-paragraphrenderer"
    },
    junk: []
  },
  {
    host: "nasa.gov",
    tagName: "div",
    attr: "class",
    value: ["article-body"]
  },
  {
    host: "news.yahoo.com",
    tagName: "article",
    junk: [
      {
        tagName: "div",
        attr: "class",
        value: ["caas-yvideo", "caas-yvideo-rendered"]
      }
    ]
  }
];
