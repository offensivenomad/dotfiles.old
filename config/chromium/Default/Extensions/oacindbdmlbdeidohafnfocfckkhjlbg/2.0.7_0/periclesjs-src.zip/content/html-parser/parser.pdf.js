const PDFJS = require('pdfjs-dist');
PDFJS.GlobalWorkerOptions.workerSrc = 'https://cdn.jsdelivr.net/npm/pdfjs-dist@2.1.266/build/pdf.worker.min.js';
const self = {
	MAX_PAGE_LIMIT: 500,

	getPageText: async (pdf, pageNo) => {
		const page = await pdf.getPage(pageNo);
		const tokenizedText = await page.getTextContent();
		console.log('Pericles.parser.pdf.getPageText().tokenizedText', tokenizedText)
		let str = '<p>';
		let lastY = 0;
		let lastStr = '';
		let y = 0;
		const pageText = tokenizedText.items.map(token => {
			y = parseInt(token.transform[5]);
			
			if (lastY > y && token.str === ' ' && lastStr !== ' ')
				str+= '</p><p>'

			if (lastY === y || !lastY)
				str += token.str;
			else if (lastY > y && token.str !== lastStr)
				str += "\r\n" + token.str
			else
				str += ' ' + token.str;

			lastStr = token.str;
			lastY = y;

			return str + '</p>'
		})
		return pageText[pageText.length-1];
	},

	getPDFText: async (source) => {
		// let self = this;
		const pdf = await PDFJS.getDocument(source).promise;
		const maxPages = pdf.numPages;
		if (maxPages > self.MAX_PAGE_LIMIT) {
			let c = confirm("The file has more than " + self.MAX_PAGE_LIMIT + " pages (safe limit), and may cause this tab to crash.\nDo you wish to continue?")
			if (!c) {
				throw new Error('PDF max page limit exceed > ' + self.MAX_PAGE_LIMIT)
			}
		}
		const pageTextPromises = [];
		for (let pageNo = 1; pageNo <= maxPages; pageNo += 1) {
		  pageTextPromises.push(self.getPageText(pdf, pageNo));
		}
		const pageTexts = await Promise.all(pageTextPromises);
		console.log('Pericles.parser.pdf.getPDFText', pageTexts)
		return pageTexts;
		// return pageTexts.join(" ");
	}

}

module.exports = self;
